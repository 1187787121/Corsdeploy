drop table CH_CHANNEL;

drop table CH_CHANNEL_SRVG_PRIV;

drop table CH_CHANNEL_SRV_PRIV;

drop table CM_SEQ;

drop table DC_DICT;

drop table DC_DICT_ENU;

drop table DP_DEPT;

drop table DP_DEPT_COL_PRIV;

drop table DP_DEPT_OPT_PRIV;

drop table DP_DEPT_RS_PRIV;

drop table DP_DEPT_SOC_PRIV;

drop table DP_DEPT_SQL_PRIV;

drop table DT_SOURCE;

drop table LG_LOG_DOWN;

drop table LG_LOG_LABEL;

drop index LG_LOG_MF_I3;

drop index LG_LOG_MF_I2;

drop index LG_LOG_MF_I1;

drop table LG_LOG_MF;

drop table MG_MSG;

drop table MG_MSG_USER;

drop table RS_OPT;

drop table RS_RES;

drop table RT_SVC_EXE;

drop table SV_REMOTE_SRV;

drop table SV_SRV;

drop table SV_SRVG;

drop table SV_SRV_AUTH;

drop table SV_SRV_CHECK;

drop table SV_SRV_SOC;

drop table TM_TERM;

drop table US_DEPT_ROLE;

drop table US_ROLE;

drop table US_ROLE_COL_PRIV;

drop table US_ROLE_OPT_PRIV;

drop table US_ROLE_RS_PRIV;

drop table US_ROLE_SOC_PRIV;

drop table US_ROLE_SQL_PRIV;

drop table US_USER;

drop table US_USER_COL_PRIV;

drop table US_USER_CONTACT;

drop table US_USER_OPT_PRIV;

drop table US_USER_ROLE;

drop table US_USER_RS_PRIV;

drop table US_USER_SOC_PRIV;

drop table US_USER_SQL_PRIV;

drop table US_USER_TERM;

drop table WK_DEAL_DETAIL;

drop index WK_DEAL_STATE_I3;

drop index WK_DEAL_STATE_I2;

drop index WK_DEAL_STATE_I1;

drop table WK_DEAL_STATE;

drop table WK_DETAIL_REGISTER;

drop table WK_WORK_PROCESS;

--==============================================================
-- Table: CH_CHANNEL
--==============================================================
create table CH_CHANNEL
(
   CHANNEL_CODE         CHAR(2)                not null,
   CHANNEL_CN_NAME      VARCHAR(50),
   CHANNEL_TYPE         INTEGER                not null default 0,
   CHANNEL_BK_DESC      VARCHAR(100),
   BACKUP_FLD           VARCHAR(50),
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (CHANNEL_CODE)
);

comment on table CH_CHANNEL is
'���������';

comment on column CH_CHANNEL.CHANNEL_CODE is
'��������';

comment on column CH_CHANNEL.CHANNEL_CN_NAME is
'������������';

comment on column CH_CHANNEL.CHANNEL_TYPE is
'��������';

comment on column CH_CHANNEL.CHANNEL_BK_DESC is
'��������';

comment on column CH_CHANNEL.BACKUP_FLD is
'�����ֶ�';

comment on column CH_CHANNEL.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: CH_CHANNEL_SRVG_PRIV
--==============================================================
create table CH_CHANNEL_SRVG_PRIV
(
   CHANNEL_CODE         CHAR(2)                not null,
   SRVG_CODE            CHAR(2)                not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (CHANNEL_CODE, SRVG_CODE)
);

comment on table CH_CHANNEL_SRVG_PRIV is
'����������Ȩ�����ñ�';

comment on column CH_CHANNEL_SRVG_PRIV.CHANNEL_CODE is
'��������';

comment on column CH_CHANNEL_SRVG_PRIV.SRVG_CODE is
'���������';

comment on column CH_CHANNEL_SRVG_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CH_CHANNEL_SRV_PRIV
--==============================================================
create table CH_CHANNEL_SRV_PRIV
(
   CHANNEL_CODE         CHAR(2)                not null,
   SRV_NAME             CHAR(50)               not null,
   AF_FLAG              INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (CHANNEL_CODE, SRV_NAME)
);

comment on table CH_CHANNEL_SRV_PRIV is
'��������Ȩ�����ñ�';

comment on column CH_CHANNEL_SRV_PRIV.CHANNEL_CODE is
'��������';

comment on column CH_CHANNEL_SRV_PRIV.SRV_NAME is
'������';

comment on column CH_CHANNEL_SRV_PRIV.AF_FLAG is
'������ֹ��־';

comment on column CH_CHANNEL_SRV_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CM_SEQ
--==============================================================
create table CM_SEQ
(
   SEQ_NAME             CHAR(6)                not null,
   CUR_BK_SEQ           BIGINT                 not null default 0,
   SEQ_FLD_LENGTH       INTEGER                not null default 0,
   SEQ_TYPE             INTEGER                not null default 0,
   LMOD_BK_DATE         DATE,
   LS_BK_SEQ            BIGINT                 not null default 0,
   constraint "P_Key_1" primary key (SEQ_NAME)
);

comment on table CM_SEQ is
'��ű�';

comment on column CM_SEQ.SEQ_NAME is
'�������';

comment on column CM_SEQ.CUR_BK_SEQ is
'��ǰ���';

comment on column CM_SEQ.SEQ_FLD_LENGTH is
'��ų���';

comment on column CM_SEQ.SEQ_TYPE is
'�������';

comment on column CM_SEQ.LMOD_BK_DATE is
'�ϴ��޸�����';

comment on column CM_SEQ.LS_BK_SEQ is
'�������';

--==============================================================
-- Table: DC_DICT
--==============================================================
create table DC_DICT
(
   DOMAIN_NAME          VARCHAR(20)            not null,
   DOMAIN_CN_NAME       VARCHAR(50),
   FLD_TYPE             VARCHAR(20),
   FLD_LENGTH           INTEGER                not null default 0,
   FLD_SCALE            INTEGER                not null default 0,
   ENU_YN_FLAG          INTEGER                not null default 0,
   constraint "P_Key_1" primary key (DOMAIN_NAME)
);

comment on table DC_DICT is
'�����ֵ���Ϣ��';

comment on column DC_DICT.DOMAIN_NAME is
'�����';

comment on column DC_DICT.DOMAIN_CN_NAME is
'����������';

comment on column DC_DICT.FLD_TYPE is
'����';

comment on column DC_DICT.FLD_LENGTH is
'�ܳ���';

comment on column DC_DICT.FLD_SCALE is
'С��λ';

comment on column DC_DICT.ENU_YN_FLAG is
'�Ƿ�ö��';

--==============================================================
-- Table: DC_DICT_ENU
--==============================================================
create table DC_DICT_ENU
(
   DOMAIN_NAME          VARCHAR(20)            not null,
   ENU_VALUE            INTEGER                not null default 0,
   ENU_CODE             VARCHAR(50),
   ENU_BK_EXPL          VARCHAR(500),
   constraint "P_Key_1" primary key (DOMAIN_NAME, ENU_VALUE)
);

comment on table DC_DICT_ENU is
'�����ֵ�ö�ٱ�';

comment on column DC_DICT_ENU.DOMAIN_NAME is
'������';

comment on column DC_DICT_ENU.ENU_VALUE is
'ѡ��ֵ';

comment on column DC_DICT_ENU.ENU_CODE is
'ѡ�����';

comment on column DC_DICT_ENU.ENU_BK_EXPL is
'ѡ��˵��';

--==============================================================
-- Table: DP_DEPT
--==============================================================
create table DP_DEPT
(
   DEPT_ID              CHAR(6)                not null,
   DEPT_CN_NAME         VARCHAR(50),
   DEPT_FULL_CNAME      VARCHAR(50),
   DEPT_TYPE            INTEGER                not null default 0,
   DEPT_LEVEL           INTEGER                not null default 0,
   BRANCH_NO            VARCHAR(10),
   SUPER_DEPT_ID        CHAR(6),
   BACKUP_FLD           VARCHAR(50),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   CRT_USER_ID          CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   DEL_BK_DATE          DATE,
   DEL_BK_TIME          TIME,
   DEL_USER_ID          CHAR(20),
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (DEPT_ID)
);

comment on table DP_DEPT is
'���ű�';

comment on column DP_DEPT.DEPT_ID is
'���ű���';

comment on column DP_DEPT.DEPT_CN_NAME is
'��������';

comment on column DP_DEPT.DEPT_FULL_CNAME is
'����ȫ��';

comment on column DP_DEPT.DEPT_TYPE is
'��������';

comment on column DP_DEPT.DEPT_LEVEL is
'���ż���';

comment on column DP_DEPT.BRANCH_NO is
'������';

comment on column DP_DEPT.SUPER_DEPT_ID is
'�ϼ����ű���';

comment on column DP_DEPT.BACKUP_FLD is
'�����ֶ�';

comment on column DP_DEPT.CRT_BK_DATE is
'��������';

comment on column DP_DEPT.CRT_BK_TIME is
'����ʱ��';

comment on column DP_DEPT.CRT_USER_ID is
'�����û�';

comment on column DP_DEPT.MODIFY_BK_DATE is
'�޸�����';

comment on column DP_DEPT.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column DP_DEPT.MODIFY_USER_ID is
'�޸��û�';

comment on column DP_DEPT.DEL_BK_DATE is
'ɾ������';

comment on column DP_DEPT.DEL_BK_TIME is
'ɾ��ʱ��';

comment on column DP_DEPT.DEL_USER_ID is
'ɾ���û�';

comment on column DP_DEPT.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: DP_DEPT_COL_PRIV
--==============================================================
create table DP_DEPT_COL_PRIV
(
   DEPT_ID              CHAR(6)                not null,
   SOC_NAME             CHAR(20)               not null,
   TBL_NAME             CHAR(50)               not null,
   COL_NAME             CHAR(50)               not null,
   INS_PRIV_FLAG        INTEGER                not null default 0,
   DEL_PRIV_FLAG        INTEGER                not null default 0,
   UPD_PRIV_FLAG        INTEGER                not null default 0,
   SEL_PRIV_FLAG        INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DEPT_ID, SOC_NAME, TBL_NAME, COL_NAME)
);

comment on table DP_DEPT_COL_PRIV is
'����SQL�ֶβ���Ȩ�ޱ�';

comment on column DP_DEPT_COL_PRIV.DEPT_ID is
'���ű���';

comment on column DP_DEPT_COL_PRIV.SOC_NAME is
'����Դ����';

comment on column DP_DEPT_COL_PRIV.TBL_NAME is
'����';

comment on column DP_DEPT_COL_PRIV.COL_NAME is
'�ֶ�����';

comment on column DP_DEPT_COL_PRIV.INS_PRIV_FLAG is
'INSERTȨ��';

comment on column DP_DEPT_COL_PRIV.DEL_PRIV_FLAG is
'DELETEȨ��';

comment on column DP_DEPT_COL_PRIV.UPD_PRIV_FLAG is
'UPDATEȨ��';

comment on column DP_DEPT_COL_PRIV.SEL_PRIV_FLAG is
'SELECTȨ��';

comment on column DP_DEPT_COL_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: DP_DEPT_OPT_PRIV
--==============================================================
create table DP_DEPT_OPT_PRIV
(
   OPT_CODE             CHAR(12)               not null,
   DEPT_ID              CHAR(6)                not null,
   PRIV_FLAG            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (OPT_CODE, DEPT_ID)
);

comment on table DP_DEPT_OPT_PRIV is
'���Ų���Ȩ�����ñ�';

comment on column DP_DEPT_OPT_PRIV.OPT_CODE is
'��������';

comment on column DP_DEPT_OPT_PRIV.DEPT_ID is
'���ű���';

comment on column DP_DEPT_OPT_PRIV.PRIV_FLAG is
'Ȩ��';

--==============================================================
-- Table: DP_DEPT_RS_PRIV
--==============================================================
create table DP_DEPT_RS_PRIV
(
   DEPT_ID              CHAR(6)                not null,
   RS_CODE              CHAR(10)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DEPT_ID, RS_CODE)
);

comment on table DP_DEPT_RS_PRIV is
'������ԴȨ�ޱ�';

comment on column DP_DEPT_RS_PRIV.DEPT_ID is
'���ű���';

comment on column DP_DEPT_RS_PRIV.RS_CODE is
'��Դ����';

comment on column DP_DEPT_RS_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: DP_DEPT_SOC_PRIV
--==============================================================
create table DP_DEPT_SOC_PRIV
(
   DEPT_ID              CHAR(6)                not null,
   SOC_NAME             CHAR(20)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DEPT_ID, SOC_NAME)
);

comment on table DP_DEPT_SOC_PRIV is
'��������ԴȨ�ޱ�';

comment on column DP_DEPT_SOC_PRIV.DEPT_ID is
'���ű���';

comment on column DP_DEPT_SOC_PRIV.SOC_NAME is
'����Դ����';

comment on column DP_DEPT_SOC_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: DP_DEPT_SQL_PRIV
--==============================================================
create table DP_DEPT_SQL_PRIV
(
   DEPT_ID              CHAR(6)                not null,
   SOC_NAME             CHAR(20)               not null,
   TBL_NAME             CHAR(50)               not null,
   INS_PRIV_FLAG        INTEGER                not null default 0,
   DEL_PRIV_FLAG        INTEGER                not null default 0,
   UPD_PRIV_FLAG        INTEGER                not null default 0,
   SEL_PRIV_FLAG        INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DEPT_ID, SOC_NAME, TBL_NAME)
);

comment on table DP_DEPT_SQL_PRIV is
'����SQL����Ȩ�ޱ�';

comment on column DP_DEPT_SQL_PRIV.DEPT_ID is
'���ű���';

comment on column DP_DEPT_SQL_PRIV.SOC_NAME is
'����Դ����';

comment on column DP_DEPT_SQL_PRIV.TBL_NAME is
'����';

comment on column DP_DEPT_SQL_PRIV.INS_PRIV_FLAG is
'INSERTȨ��';

comment on column DP_DEPT_SQL_PRIV.DEL_PRIV_FLAG is
'DELETEȨ��';

comment on column DP_DEPT_SQL_PRIV.UPD_PRIV_FLAG is
'UPDATEȨ��';

comment on column DP_DEPT_SQL_PRIV.SEL_PRIV_FLAG is
'SELECTȨ��';

comment on column DP_DEPT_SQL_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: DT_SOURCE
--==============================================================
create table DT_SOURCE
(
   SOC_NAME             CHAR(20)               not null,
   SOC_IP               CHAR(20),
   SOC_PORT             INTEGER                not null default 0,
   PROTOCOL_TYPE        INTEGER                not null default 0,
   REMOTE_UNAME         VARCHAR(20),
   REMOTE_PASSWD        VARCHAR(32),
   KEY_REMOTE_PASSWD    VARCHAR(32)            not null,
   BK_TIMEOUT           BIGINT                 not null default 0,
   JDBC_DRV             VARCHAR(50),
   JDBC_URL             VARCHAR(100),
   JDBC_SCHEMA          VARCHAR(50),
   CVT_TYPE             INTEGER                not null default 0,
   FTP_LOCAL_SCRIPT     VARCHAR(50),
   CVT_LOCAL_SCRIPT     VARCHAR(50),
   SOC_DOMAIN           CHAR(20),
   SOC_BK_DESC          VARCHAR(100),
   SOC_PARAMS           VARCHAR(500),
   USER_ROOT_PATH       VARCHAR(200),
   BACKUP_FLD           VARCHAR(50),
   RCD_STATE            INTEGER                not null default 0,
   ENVIRONMENT_VARIABLES VARCHAR(500),
   ENCODING_TYPE        VARCHAR(20),
   constraint "P_Key_1" primary key (SOC_NAME)
);

comment on table DT_SOURCE is
'����Դ��Ϣ��';

comment on column DT_SOURCE.SOC_NAME is
'����Դ����';

comment on column DT_SOURCE.SOC_IP is
'IP��ַ';

comment on column DT_SOURCE.SOC_PORT is
'�˿ں�';

comment on column DT_SOURCE.PROTOCOL_TYPE is
'Э������';

comment on column DT_SOURCE.REMOTE_UNAME is
'��������½�û���';

comment on column DT_SOURCE.REMOTE_PASSWD is
'��������½����';

comment on column DT_SOURCE.KEY_REMOTE_PASSWD is
'��Կ';

comment on column DT_SOURCE.BK_TIMEOUT is
'��ʱʱ��';

comment on column DT_SOURCE.JDBC_DRV is
'Jdbc_driver';

comment on column DT_SOURCE.JDBC_URL is
'Jdbc_url';

comment on column DT_SOURCE.JDBC_SCHEMA is
'Jdbc_schema';

comment on column DT_SOURCE.CVT_TYPE is
'ת�뷽ʽ';

comment on column DT_SOURCE.FTP_LOCAL_SCRIPT is
'���´��ű�';

comment on column DT_SOURCE.CVT_LOCAL_SCRIPT is
'ת��ű�';

comment on column DT_SOURCE.SOC_DOMAIN is
'����Դ����';

comment on column DT_SOURCE.SOC_BK_DESC is
'����Դ����';

comment on column DT_SOURCE.SOC_PARAMS is
'����Դ����';

comment on column DT_SOURCE.USER_ROOT_PATH is
'�û���·��';

comment on column DT_SOURCE.BACKUP_FLD is
'�����ֶ�';

comment on column DT_SOURCE.RCD_STATE is
'��¼״̬';

comment on column DT_SOURCE.ENVIRONMENT_VARIABLES is
'��������';

comment on column DT_SOURCE.ENCODING_TYPE is
'�����ʽ';

--==============================================================
-- Table: LG_LOG_DOWN
--==============================================================
create table LG_LOG_DOWN
(
   LOG_ROOT_PATH        VARCHAR(200)           not null,
   LOG_FILE_NAME        VARCHAR(50)            not null,
   START_BK_DATE        DATE,
   END_BK_DATE          DATE,
   USER_ID              CHAR(20),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (LOG_ROOT_PATH, LOG_FILE_NAME)
);

comment on table LG_LOG_DOWN is
'����������Ϣ��';

comment on column LG_LOG_DOWN.LOG_ROOT_PATH is
'��־�ļ�·��';

comment on column LG_LOG_DOWN.LOG_FILE_NAME is
'��־�ļ�����';

comment on column LG_LOG_DOWN.START_BK_DATE is
'��־��ʼ����';

comment on column LG_LOG_DOWN.END_BK_DATE is
'��־��ֹ����';

comment on column LG_LOG_DOWN.USER_ID is
'�û���';

comment on column LG_LOG_DOWN.CRT_BK_DATE is
'������־����';

comment on column LG_LOG_DOWN.CRT_BK_TIME is
'������־ʱ��';

comment on column LG_LOG_DOWN.BACKUP_FLD is
'����';

--==============================================================
-- Table: LG_LOG_LABEL
--==============================================================
create table LG_LOG_LABEL
(
   WORK_SEQ             CHAR(17)               not null,
   USER_ID              CHAR(20)               not null,
   LOG_LABEL            INTEGER                not null default 0,
   LABEL_BK_DATE        DATE,
   LABEL_BK_TIME        TIME,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (WORK_SEQ, USER_ID)
);

comment on table LG_LOG_LABEL is
'��־��Ǽ����';

comment on column LG_LOG_LABEL.WORK_SEQ is
'������ˮ��';

comment on column LG_LOG_LABEL.USER_ID is
'�û���';

comment on column LG_LOG_LABEL.LOG_LABEL is
'��־���';

comment on column LG_LOG_LABEL.LABEL_BK_DATE is
'�������';

comment on column LG_LOG_LABEL.LABEL_BK_TIME is
'���ʱ��';

comment on column LG_LOG_LABEL.BACKUP_FLD is
'����';

--==============================================================
-- Table: LG_LOG_MF
--==============================================================
create table LG_LOG_MF
(
   WORK_SEQ             CHAR(17)               not null,
   ORG_CHANNEL_CODE     CHAR(2),
   ORG_TERM_NO          CHAR(40),
   ORG_WORK_CODE        CHAR(10),
   ORG_SRV_NAME         CHAR(50),
   ORG_SRV_BK_DESC      VARCHAR(100),
   ORG_RS_CODE          CHAR(10),
   ORG_ARY_SOCNAME      VARCHAR(100),
   PEND_WORK_SEQ        CHAR(17),
   PEND_WORK_CODE       CHAR(10),
   PEND_SRV_NAME        CHAR(50),
   PEND_RS_CODE         CHAR(10),
   PEND_ARY_SOCNAME     VARCHAR(100),
   PENDWK_BK_EXPL       VARCHAR(500),
   PBL_CODE             VARCHAR(20),
   SR_YN_FLAG           INTEGER                not null default 0,
   CRT_USER_ID          CHAR(20),
   CRT_USER_CN_NAME     VARCHAR(50),
   CRT_DEPT_ID          CHAR(6),
   CRT_DEPT_CN_NAME     VARCHAR(50),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   LOG_TXT              VARCHAR(1000),
   LOG_LEVEL            INTEGER,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (WORK_SEQ)
);

comment on table LG_LOG_MF is
'������־��ˮ��';

comment on column LG_LOG_MF.WORK_SEQ is
'������ˮ��';

comment on column LG_LOG_MF.ORG_CHANNEL_CODE is
'��������';

comment on column LG_LOG_MF.ORG_TERM_NO is
'�����ն�';

comment on column LG_LOG_MF.ORG_WORK_CODE is
'�����������';

comment on column LG_LOG_MF.ORG_SRV_NAME is
'���������';

comment on column LG_LOG_MF.ORG_SRV_BK_DESC is
'�����������';

comment on column LG_LOG_MF.ORG_RS_CODE is
'������Դ����';

comment on column LG_LOG_MF.ORG_ARY_SOCNAME is
'��������Դ����';

comment on column LG_LOG_MF.PEND_WORK_SEQ is
'��������ˮ��';

comment on column LG_LOG_MF.PEND_WORK_CODE is
'�������������';

comment on column LG_LOG_MF.PEND_SRV_NAME is
'��������������';

comment on column LG_LOG_MF.PEND_RS_CODE is
'��������Դ����';

comment on column LG_LOG_MF.PEND_ARY_SOCNAME is
'����������Դ����';

comment on column LG_LOG_MF.PENDWK_BK_EXPL is
'����������˵��';

comment on column LG_LOG_MF.PBL_CODE is
'���ⵥ����';

comment on column LG_LOG_MF.SR_YN_FLAG is
'�ɹ���׼';

comment on column LG_LOG_MF.CRT_USER_ID is
'�����û�';

comment on column LG_LOG_MF.CRT_USER_CN_NAME is
'�û�������';

comment on column LG_LOG_MF.CRT_DEPT_ID is
'��������';

comment on column LG_LOG_MF.CRT_DEPT_CN_NAME is
'����������';

comment on column LG_LOG_MF.CRT_BK_DATE is
'��������';

comment on column LG_LOG_MF.CRT_BK_TIME is
'����ʱ��';

comment on column LG_LOG_MF.LOG_TXT is
'��־����';

comment on column LG_LOG_MF.LOG_LEVEL is
'��־����';

comment on column LG_LOG_MF.BACKUP_FLD is
'����';

--==============================================================
-- Index: LG_LOG_MF_I1
--==============================================================
create index LG_LOG_MF_I1 on LG_LOG_MF (
   LOG_LEVEL            ASC
);

--==============================================================
-- Index: LG_LOG_MF_I2
--==============================================================
create index LG_LOG_MF_I2 on LG_LOG_MF (
   CRT_BK_DATE          ASC
);

--==============================================================
-- Index: LG_LOG_MF_I3
--==============================================================
create index LG_LOG_MF_I3 on LG_LOG_MF (
   CRT_USER_ID          ASC
);

--==============================================================
-- Table: MG_MSG
--==============================================================
create table MG_MSG
(
   WORK_SEQ             CHAR(17)               not null,
   MSG_TITLE            VARCHAR(200),
   MSG_TEXT             VARCHAR(1000),
   MSG_TYPE             INTEGER                not null default 0,
   FILE_PATH            VARCHAR(200),
   FIRST_BK_FNAME       VARCHAR(50),
   SECD_BK_FNAME        VARCHAR(50),
   THIRD_BK_FNAME       VARCHAR(50),
   BACKUP_FLD           VARCHAR(50),
   CRT_USER_ID          CHAR(20),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   DEL_YN_FLAG          INTEGER                not null default 0,
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (WORK_SEQ)
);

comment on table MG_MSG is
'��Ϣ��Ϣ��';

comment on column MG_MSG.WORK_SEQ is
'��Ϣ��ˮ��';

comment on column MG_MSG.MSG_TITLE is
'��Ϣ����';

comment on column MG_MSG.MSG_TEXT is
'��Ϣ����';

comment on column MG_MSG.MSG_TYPE is
'��Ϣ����';

comment on column MG_MSG.FILE_PATH is
'�ļ�·��';

comment on column MG_MSG.FIRST_BK_FNAME is
'�ļ���1';

comment on column MG_MSG.SECD_BK_FNAME is
'�ļ���2';

comment on column MG_MSG.THIRD_BK_FNAME is
'�ļ���3';

comment on column MG_MSG.BACKUP_FLD is
'�����ֶ�';

comment on column MG_MSG.CRT_USER_ID is
'�����û�';

comment on column MG_MSG.CRT_BK_DATE is
'��������';

comment on column MG_MSG.CRT_BK_TIME is
'����ʱ��';

comment on column MG_MSG.DEL_YN_FLAG is
'ɾ��״̬';

comment on column MG_MSG.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: MG_MSG_USER
--==============================================================
create table MG_MSG_USER
(
   WORK_SEQ             CHAR(17)               not null,
   RC_USER_ID           CHAR(20)               not null,
   RC_FLAG              INTEGER                not null default 0,
   ATTENT_YN_FLAG       INTEGER                not null default 0,
   RC_BK_DATE           DATE,
   RC_BK_TIME           TIME,
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (WORK_SEQ, RC_USER_ID)
);

comment on table MG_MSG_USER is
'��Ϣ�û����ձ�';

comment on column MG_MSG_USER.WORK_SEQ is
'��Ϣ��ˮ��';

comment on column MG_MSG_USER.RC_USER_ID is
'�����û�';

comment on column MG_MSG_USER.RC_FLAG is
'����״̬';

comment on column MG_MSG_USER.ATTENT_YN_FLAG is
'��ע״̬';

comment on column MG_MSG_USER.RC_BK_DATE is
'��������';

comment on column MG_MSG_USER.RC_BK_TIME is
'����ʱ��';

comment on column MG_MSG_USER.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: RS_OPT
--==============================================================
create table RS_OPT
(
   OPT_CODE             CHAR(12)               not null,
   BL_RS_CODE           CHAR(10),
   OPT_BK_SEQ           BIGINT,
   OPT_NAME             VARCHAR(50),
   OPT_BK_EXPL          VARCHAR(500),
   DIS_EXPRESS          VARCHAR(200),
   CRT_USER_ID          CHAR(20),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   BACKUP_FLD           VARCHAR(50),
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (OPT_CODE)
);

comment on table RS_OPT is
'��Դ���������';

comment on column RS_OPT.OPT_CODE is
'��������';

comment on column RS_OPT.BL_RS_CODE is
'������Դ����';

comment on column RS_OPT.OPT_BK_SEQ is
'�������';

comment on column RS_OPT.OPT_NAME is
'������';

comment on column RS_OPT.OPT_BK_EXPL is
'����˵��';

comment on column RS_OPT.DIS_EXPRESS is
'���ñ���ʽ';

comment on column RS_OPT.CRT_USER_ID is
'�����û�';

comment on column RS_OPT.CRT_BK_DATE is
'��������';

comment on column RS_OPT.CRT_BK_TIME is
'����ʱ��';

comment on column RS_OPT.BACKUP_FLD is
'�����ֶ�';

comment on column RS_OPT.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: RS_RES
--==============================================================
create table RS_RES
(
   RS_CODE              CHAR(10)               not null,
   SUPER_RS_CODE        CHAR(10),
   BL_RS_CODE           CHAR(10),
   RS_FUN_TYPE          INTEGER                not null default 0,
   RS_CN_NAME           VARCHAR(50),
   RS_BK_DESC           VARCHAR(100),
   RS_URL               VARCHAR(200),
   RSIM_URL             VARCHAR(200),
   RS_LEVEL             INTEGER                not null default 0,
   GHEIGHT_BK_PIXEL     VARCHAR(6),
   PWIDTH_BK_PIXEL      VARCHAR(6),
   TITLE_ABLE           INTEGER                not null default 0,
   PUBLIC_YN_FLAG       INTEGER                not null,
   OPEN_TYPE            INTEGER                not null default 0,
   SORT_KEY             INTEGER                not null default 0,
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (RS_CODE)
);

comment on table RS_RES is
'��Դ���ñ�';

comment on column RS_RES.RS_CODE is
'��Դ����';

comment on column RS_RES.SUPER_RS_CODE is
'�ϼ���Դ����';

comment on column RS_RES.BL_RS_CODE is
'����һ����Դ����';

comment on column RS_RES.RS_FUN_TYPE is
'��Դ����';

comment on column RS_RES.RS_CN_NAME is
'��Դ����';

comment on column RS_RES.RS_BK_DESC is
'��Դ����';

comment on column RS_RES.RS_URL is
'��Դ��ַ';

comment on column RS_RES.RSIM_URL is
'��Դͼ���ַ';

comment on column RS_RES.RS_LEVEL is
'��Դ����';

comment on column RS_RES.GHEIGHT_BK_PIXEL is
'�߶�';

comment on column RS_RES.PWIDTH_BK_PIXEL is
'����';

comment on column RS_RES.TITLE_ABLE is
'�Ƿ��б���';

comment on column RS_RES.PUBLIC_YN_FLAG is
'�Ƿ񹫿�';

comment on column RS_RES.OPEN_TYPE is
'��������';

comment on column RS_RES.SORT_KEY is
'�����';

comment on column RS_RES.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: RT_SVC_EXE
--==============================================================
create table RT_SVC_EXE
(
   WORK_SEQ             CHAR(17)               not null,
   SOC_NAME             CHAR(20),
   START_BK_DATE        DATE,
   START_BK_TIME        TIME,
   END_BK_DATE          DATE,
   END_BK_TIME          TIME,
   CUR_PROC_STATE       INTEGER                not null default 0,
   PROC_NAME            VARCHAR(20),
   PROC_NUM             VARCHAR(10),
   BL_USER_ID           CHAR(20),
   RUN_CMD_STR          VARCHAR(500),
   ORG_USER_ID          CHAR(20),
   RS_BK_TEXT           VARCHAR(1000),
   ONE_BACKUP_FLD       VARCHAR(50),
   TWO_BACKUP_FLD       VARCHAR(50),
   THREE_BACKUP_FLD     VARCHAR(50),
   constraint "P_Key_1" primary key (WORK_SEQ)
);

comment on table RT_SVC_EXE is
'Զ�̷���ִ����Ϣ��';

comment on column RT_SVC_EXE.WORK_SEQ is
'������ˮ��';

comment on column RT_SVC_EXE.SOC_NAME is
'����Դ����';

comment on column RT_SVC_EXE.START_BK_DATE is
'��ʼ����';

comment on column RT_SVC_EXE.START_BK_TIME is
'��ʼʱ��';

comment on column RT_SVC_EXE.END_BK_DATE is
'��������';

comment on column RT_SVC_EXE.END_BK_TIME is
'����ʱ��';

comment on column RT_SVC_EXE.CUR_PROC_STATE is
'��ǰ״̬';

comment on column RT_SVC_EXE.PROC_NAME is
'��������';

comment on column RT_SVC_EXE.PROC_NUM is
'���̺�';

comment on column RT_SVC_EXE.BL_USER_ID is
'���������û�';

comment on column RT_SVC_EXE.RUN_CMD_STR is
'ִ�г���';

comment on column RT_SVC_EXE.ORG_USER_ID is
'�ύ�û�';

comment on column RT_SVC_EXE.RS_BK_TEXT is
'���н��';

comment on column RT_SVC_EXE.ONE_BACKUP_FLD is
'�����ֶ�1';

comment on column RT_SVC_EXE.TWO_BACKUP_FLD is
'�����ֶ�2';

comment on column RT_SVC_EXE.THREE_BACKUP_FLD is
'�����ֶ�3';

--==============================================================
-- Table: SV_REMOTE_SRV
--==============================================================
create table SV_REMOTE_SRV
(
   SRV_NAME             CHAR(50)               not null,
   DEAL_SEQ             INTEGER                not null default 0,
   REMOTE_SRV_NAME      CHAR(50),
   SRV_TYPE             CHAR(10),
   SRV_ROOT_PATH        VARCHAR(200),
   constraint "P_Key_1" primary key (SRV_NAME, DEAL_SEQ)
);

comment on table SV_REMOTE_SRV is
'Զ�̷���������ñ�';

comment on column SV_REMOTE_SRV.SRV_NAME is
'��������';

comment on column SV_REMOTE_SRV.DEAL_SEQ is
'�������';

comment on column SV_REMOTE_SRV.REMOTE_SRV_NAME is
'Ŀ����������';

comment on column SV_REMOTE_SRV.SRV_TYPE is
'Ŀ��������������';

comment on column SV_REMOTE_SRV.SRV_ROOT_PATH is
'����·��';

--==============================================================
-- Table: SV_SRV
--==============================================================
create table SV_SRV
(
   SRV_NAME             CHAR(50)               not null,
   SUP_SRVG_CODE        CHAR(2),
   SRV_BK_DESC          VARCHAR(100),
   SRV_FUN_TYPE         INTEGER                not null default 0,
   SRV_CLASS_NAME       VARCHAR(100),
   SRV_METHOD_NAME      VARCHAR(50),
   CHECK_FLAG           INTEGER                not null default 0,
   AUTH_FLAG            INTEGER                not null default 0,
   SOC_FLAG             INTEGER                not null default 0,
   SALLOW_FLAG          INTEGER                not null default 0,
   LOG_LEVEL            INTEGER                not null default 0,
   RCD_STATE            INTEGER                not null default 0,
   APROV_TYPE           INTEGER,
   CUSTOM_RS_CODE       CHAR(10),
   constraint "P_Key_1" primary key (SRV_NAME)
);

comment on table SV_SRV is
'�������ñ�';

comment on column SV_SRV.SRV_NAME is
'��������';

comment on column SV_SRV.SUP_SRVG_CODE is
'�������������';

comment on column SV_SRV.SRV_BK_DESC is
'��������';

comment on column SV_SRV.SRV_FUN_TYPE is
'��������';

comment on column SV_SRV.SRV_CLASS_NAME is
'��������';

comment on column SV_SRV.SRV_METHOD_NAME is
'���񷽷���';

comment on column SV_SRV.CHECK_FLAG is
'�Ƿ񸴺�';

comment on column SV_SRV.AUTH_FLAG is
'�Ƿ���Ȩ';

comment on column SV_SRV.SOC_FLAG is
'�Ƿ�������Դ';

comment on column SV_SRV.SALLOW_FLAG is
'����������־';

comment on column SV_SRV.LOG_LEVEL is
'��־����';

comment on column SV_SRV.RCD_STATE is
'��¼״̬';

comment on column SV_SRV.APROV_TYPE is
'����չʾ����';

comment on column SV_SRV.CUSTOM_RS_CODE is
'����ҳ����Դ����';

--==============================================================
-- Table: SV_SRVG
--==============================================================
create table SV_SRVG
(
   SRVG_CODE            CHAR(2)                not null,
   SRVG_CN_NAME         VARCHAR(50),
   SRVG_BK_DESC         VARCHAR(100),
   SRVG_FUN_TYPE        INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (SRVG_CODE)
);

comment on table SV_SRVG is
'�����鶨���';

comment on column SV_SRVG.SRVG_CODE is
'���������';

comment on column SV_SRVG.SRVG_CN_NAME is
'����������';

comment on column SV_SRVG.SRVG_BK_DESC is
'����������';

comment on column SV_SRVG.SRVG_FUN_TYPE is
'����������';

comment on column SV_SRVG.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: SV_SRV_AUTH
--==============================================================
create table SV_SRV_AUTH
(
   AUTH_DEPT_ID         CHAR(6)                not null,
   SRV_NAME             CHAR(50)               not null,
   AUTH_SEQ             INTEGER                not null default 0,
   AUTH_TYPE            INTEGER                not null default 0,
   AUTH_APROV_CATEGORY  INTEGER                not null default 0,
   AUTH_DPRL_CODE       CHAR(8),
   ROLE_CN_NAME         VARCHAR(50),
   SUPER_FLAG           INTEGER,
   constraint "P_Key_1" primary key (AUTH_DEPT_ID, SRV_NAME, AUTH_SEQ)
);

comment on table SV_SRV_AUTH is
'������Ȩ�����';

comment on column SV_SRV_AUTH.AUTH_DEPT_ID is
'���ò��ű���';

comment on column SV_SRV_AUTH.SRV_NAME is
'��������';

comment on column SV_SRV_AUTH.AUTH_SEQ is
'��Ȩ���';

comment on column SV_SRV_AUTH.AUTH_TYPE is
'��Ȩ����';

comment on column SV_SRV_AUTH.AUTH_APROV_CATEGORY is
'�������';

comment on column SV_SRV_AUTH.AUTH_DPRL_CODE is
'��Ȩ���Ž�ɫ';

comment on column SV_SRV_AUTH.ROLE_CN_NAME is
'��ɫ����';

comment on column SV_SRV_AUTH.SUPER_FLAG is
'�Ƿ��ϼ�����';

--==============================================================
-- Table: SV_SRV_CHECK
--==============================================================
create table SV_SRV_CHECK
(
   CHECK_DEPT_ID        CHAR(6)                not null,
   SRV_NAME             CHAR(50)               not null,
   CHECK_SEQ            INTEGER                not null default 0,
   CHK_APROV_CATEGORY   INTEGER                not null default 0,
   CHK_DPRL_CODE        CHAR(8),
   ROLE_CN_NAME         VARCHAR(50),
   SUPER_FLAG           INTEGER,
   constraint "P_Key_1" primary key (CHECK_DEPT_ID, SRV_NAME, CHECK_SEQ)
);

comment on table SV_SRV_CHECK is
'���񸴺˶����';

comment on column SV_SRV_CHECK.CHECK_DEPT_ID is
'���ò��ű���';

comment on column SV_SRV_CHECK.SRV_NAME is
'��������';

comment on column SV_SRV_CHECK.CHECK_SEQ is
'�������';

comment on column SV_SRV_CHECK.CHK_APROV_CATEGORY is
'�������';

comment on column SV_SRV_CHECK.CHK_DPRL_CODE is
'���˲��Ž�ɫ';

comment on column SV_SRV_CHECK.ROLE_CN_NAME is
'��ɫ����';

comment on column SV_SRV_CHECK.SUPER_FLAG is
'�Ƿ��ϼ�����';

--==============================================================
-- Table: SV_SRV_SOC
--==============================================================
create table SV_SRV_SOC
(
   SRV_NAME             CHAR(50)               not null,
   SOC_NAME             CHAR(20)               not null,
   SOC_SEQ              INTEGER                not null default 0,
   constraint "P_Key_1" primary key (SRV_NAME, SOC_NAME)
);

comment on table SV_SRV_SOC is
'��������Դ���ñ�';

comment on column SV_SRV_SOC.SRV_NAME is
'��������';

comment on column SV_SRV_SOC.SOC_NAME is
'����Դ����';

comment on column SV_SRV_SOC.SOC_SEQ is
'����Դ˳���';

--==============================================================
-- Table: TM_TERM
--==============================================================
create table TM_TERM
(
   TERM_NO              CHAR(40)               not null,
   TERM_TYPE            INTEGER                not null default 0,
   TERM_BK_DESC         VARCHAR(100),
   CRT_USER_ID          CHAR(20),
   CRT_DEPT_ID          CHAR(6),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (TERM_NO)
);

comment on table TM_TERM is
'�ն����ñ�';

comment on column TM_TERM.TERM_NO is
'�ն˺�';

comment on column TM_TERM.TERM_TYPE is
'�ն�����';

comment on column TM_TERM.TERM_BK_DESC is
'�ն�˵��';

comment on column TM_TERM.CRT_USER_ID is
'�����û�';

comment on column TM_TERM.CRT_DEPT_ID is
'��������';

comment on column TM_TERM.CRT_BK_DATE is
'��������';

comment on column TM_TERM.CRT_BK_TIME is
'����ʱ��';

comment on column TM_TERM.BACKUP_FLD is
'����';

--==============================================================
-- Table: US_DEPT_ROLE
--==============================================================
create table US_DEPT_ROLE
(
   DPRL_CODE            CHAR(8)                not null,
   DEPT_ID              CHAR(6),
   ROLE_CODE            CHAR(2),
   BK_EXPL              VARCHAR(500),
   constraint "P_Key_1" primary key (DPRL_CODE)
);

comment on table US_DEPT_ROLE is
'���Ž�ɫ������';

comment on column US_DEPT_ROLE.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_DEPT_ROLE.DEPT_ID is
'���ű���';

comment on column US_DEPT_ROLE.ROLE_CODE is
'��ɫ����';

comment on column US_DEPT_ROLE.BK_EXPL is
'���Ž�ɫ˵��';

--==============================================================
-- Table: US_ROLE
--==============================================================
create table US_ROLE
(
   ROLE_CODE            CHAR(2)                not null,
   ROLE_CN_NAME         VARCHAR(50),
   ROLE_TYPE            INTEGER                not null default 0,
   ROLE_BK_DESC         VARCHAR(100),
   BACKUP_FLD           VARCHAR(50),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   CRT_USER_ID          CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   DEL_BK_DATE          DATE,
   DEL_BK_TIME          TIME,
   DEL_USER_ID          CHAR(20),
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (ROLE_CODE)
);

comment on table US_ROLE is
'��ɫ�ű�';

comment on column US_ROLE.ROLE_CODE is
'��ɫ����';

comment on column US_ROLE.ROLE_CN_NAME is
'��ɫ����';

comment on column US_ROLE.ROLE_TYPE is
'��ɫ����';

comment on column US_ROLE.ROLE_BK_DESC is
'��ɫ˵��';

comment on column US_ROLE.BACKUP_FLD is
'�����ֶ�';

comment on column US_ROLE.CRT_BK_DATE is
'��������';

comment on column US_ROLE.CRT_BK_TIME is
'����ʱ��';

comment on column US_ROLE.CRT_USER_ID is
'�����û�';

comment on column US_ROLE.MODIFY_BK_DATE is
'�޸�����';

comment on column US_ROLE.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column US_ROLE.MODIFY_USER_ID is
'�޸��û�';

comment on column US_ROLE.DEL_BK_DATE is
'ɾ������';

comment on column US_ROLE.DEL_BK_TIME is
'ɾ��ʱ��';

comment on column US_ROLE.DEL_USER_ID is
'ɾ���û�';

comment on column US_ROLE.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: US_ROLE_COL_PRIV
--==============================================================
create table US_ROLE_COL_PRIV
(
   DPRL_CODE            CHAR(8)                not null,
   SOC_NAME             CHAR(20)               not null,
   TBL_NAME             CHAR(50)               not null,
   COL_NAME             CHAR(50)               not null,
   INS_PRIV_FLAG        INTEGER                not null default 0,
   DEL_PRIV_FLAG        INTEGER                not null default 0,
   UPD_PRIV_FLAG        INTEGER                not null default 0,
   SEL_PRIV_FLAG        INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DPRL_CODE, SOC_NAME, TBL_NAME, COL_NAME)
);

comment on table US_ROLE_COL_PRIV is
'���Ž�ɫSQL�ֶβ���Ȩ�ޱ�';

comment on column US_ROLE_COL_PRIV.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_ROLE_COL_PRIV.SOC_NAME is
'����Դ����';

comment on column US_ROLE_COL_PRIV.TBL_NAME is
'����';

comment on column US_ROLE_COL_PRIV.COL_NAME is
'�ֶ�����';

comment on column US_ROLE_COL_PRIV.INS_PRIV_FLAG is
'InsertȨ��';

comment on column US_ROLE_COL_PRIV.DEL_PRIV_FLAG is
'DeleteȨ��';

comment on column US_ROLE_COL_PRIV.UPD_PRIV_FLAG is
'UpdateȨ��';

comment on column US_ROLE_COL_PRIV.SEL_PRIV_FLAG is
'SelectȨ��';

comment on column US_ROLE_COL_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_ROLE_OPT_PRIV
--==============================================================
create table US_ROLE_OPT_PRIV
(
   OPT_CODE             CHAR(12)               not null,
   DPRL_CODE            CHAR(8)                not null,
   PRIV_FLAG            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (OPT_CODE, DPRL_CODE)
);

comment on table US_ROLE_OPT_PRIV is
'���Ž�ɫ����Ȩ�����ñ�';

comment on column US_ROLE_OPT_PRIV.OPT_CODE is
'��������';

comment on column US_ROLE_OPT_PRIV.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_ROLE_OPT_PRIV.PRIV_FLAG is
'Ȩ��';

--==============================================================
-- Table: US_ROLE_RS_PRIV
--==============================================================
create table US_ROLE_RS_PRIV
(
   DPRL_CODE            CHAR(8)                not null,
   RS_CODE              CHAR(10)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DPRL_CODE, RS_CODE)
);

comment on table US_ROLE_RS_PRIV is
'���Ž�ɫ��ԴȨ�ޱ�';

comment on column US_ROLE_RS_PRIV.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_ROLE_RS_PRIV.RS_CODE is
'��Դ����';

comment on column US_ROLE_RS_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_ROLE_SOC_PRIV
--==============================================================
create table US_ROLE_SOC_PRIV
(
   DPRL_CODE            CHAR(8)                not null,
   SOC_NAME             CHAR(20)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DPRL_CODE, SOC_NAME)
);

comment on table US_ROLE_SOC_PRIV is
'���Ž�ɫ����ԴȨ�ޱ�';

comment on column US_ROLE_SOC_PRIV.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_ROLE_SOC_PRIV.SOC_NAME is
'����Դ����';

comment on column US_ROLE_SOC_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_ROLE_SQL_PRIV
--==============================================================
create table US_ROLE_SQL_PRIV
(
   DPRL_CODE            CHAR(8)                not null,
   SOC_NAME             CHAR(20)               not null,
   TBL_NAME             CHAR(50)               not null,
   INS_PRIV_FLAG        INTEGER                not null default 0,
   DEL_PRIV_FLAG        INTEGER                not null default 0,
   UPD_PRIV_FLAG        INTEGER                not null default 0,
   SEL_PRIV_FLAG        INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (DPRL_CODE, SOC_NAME, TBL_NAME)
);

comment on table US_ROLE_SQL_PRIV is
'���Ž�ɫSQL����Ȩ�ޱ�';

comment on column US_ROLE_SQL_PRIV.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_ROLE_SQL_PRIV.SOC_NAME is
'����Դ����';

comment on column US_ROLE_SQL_PRIV.TBL_NAME is
'����';

comment on column US_ROLE_SQL_PRIV.INS_PRIV_FLAG is
'InsertȨ��';

comment on column US_ROLE_SQL_PRIV.DEL_PRIV_FLAG is
'DeleteȨ��';

comment on column US_ROLE_SQL_PRIV.UPD_PRIV_FLAG is
'UpdateȨ��';

comment on column US_ROLE_SQL_PRIV.SEL_PRIV_FLAG is
'SelectȨ��';

comment on column US_ROLE_SQL_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER
--==============================================================
create table US_USER
(
   USER_ID              CHAR(20)               not null,
   USER_PASSWD          CHAR(32),
   PWDEXP_BK_DATE       DATE,
   USER_CN_NAME         VARCHAR(50),
   EMAIL_ADD            VARCHAR(50),
   PHONE_NO             VARCHAR(12),
   TELLER_NO            CHAR(6),
   LOGIN_BK_NUM         INTEGER                not null default 0,
   BL_DEPT_ID           CHAR(6),
   USER_TYPE            INTEGER                not null default 0,
   FIRST_DEPT_ID        CHAR(6),
   SECD_DEPT_ID         CHAR(6),
   THIRD_DEPT_ID        CHAR(6),
   BACKUP_FLD           VARCHAR(50),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   CRT_USER_ID          CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   DEL_BK_DATE          DATE,
   DEL_BK_TIME          TIME,
   DEL_USER_ID          CHAR(20),
   RCD_STATE            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (USER_ID)
);

comment on table US_USER is
'�û���';

comment on column US_USER.USER_ID is
'�û���';

comment on column US_USER.USER_PASSWD is
'�û�����';

comment on column US_USER.PWDEXP_BK_DATE is
'���뵽����';

comment on column US_USER.USER_CN_NAME is
'�û�����';

comment on column US_USER.EMAIL_ADD is
'����';

comment on column US_USER.PHONE_NO is
'�绰����';

comment on column US_USER.TELLER_NO is
'��Ա��';

comment on column US_USER.LOGIN_BK_NUM is
'�û���¼����';

comment on column US_USER.BL_DEPT_ID is
'�������ź�';

comment on column US_USER.USER_TYPE is
'�û�����';

comment on column US_USER.FIRST_DEPT_ID is
'��ְ����1';

comment on column US_USER.SECD_DEPT_ID is
'��ְ����2';

comment on column US_USER.THIRD_DEPT_ID is
'��ְ����3';

comment on column US_USER.BACKUP_FLD is
'�����ֶ�';

comment on column US_USER.CRT_BK_DATE is
'��������';

comment on column US_USER.CRT_BK_TIME is
'����ʱ��';

comment on column US_USER.CRT_USER_ID is
'�����û�';

comment on column US_USER.MODIFY_BK_DATE is
'�޸�����';

comment on column US_USER.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column US_USER.MODIFY_USER_ID is
'�޸��û�';

comment on column US_USER.DEL_BK_DATE is
'ɾ������';

comment on column US_USER.DEL_BK_TIME is
'ɾ��ʱ��';

comment on column US_USER.DEL_USER_ID is
'ɾ���û�';

comment on column US_USER.RCD_STATE is
'��¼״̬';

--==============================================================
-- Table: US_USER_COL_PRIV
--==============================================================
create table US_USER_COL_PRIV
(
   USER_ID              CHAR(20)               not null,
   SOC_NAME             CHAR(20)               not null,
   TBL_NAME             CHAR(50)               not null,
   COL_NAME             CHAR(50)               not null,
   PRIV_TYPE            INTEGER                not null default 0,
   INS_PRIV_FLAG        INTEGER                not null default 0,
   DEL_PRIV_FLAG        INTEGER                not null default 0,
   UPD_PRIV_FLAG        INTEGER                not null default 0,
   SEL_PRIV_FLAG        INTEGER                not null default 0,
   AF_FLAG              INTEGER                not null default 0,
   TEMPSTART_BK_DATETIME TIMESTAMP,
   TEMPEND_BK_DATETIME  TIMESTAMP,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, SOC_NAME, TBL_NAME, COL_NAME, PRIV_TYPE)
);

comment on table US_USER_COL_PRIV is
'�û�SQL�ֶβ���Ȩ�ޱ�';

comment on column US_USER_COL_PRIV.USER_ID is
'�û���';

comment on column US_USER_COL_PRIV.SOC_NAME is
'����Դ����';

comment on column US_USER_COL_PRIV.TBL_NAME is
'����';

comment on column US_USER_COL_PRIV.COL_NAME is
'�ֶ�����';

comment on column US_USER_COL_PRIV.PRIV_TYPE is
'��Դ����';

comment on column US_USER_COL_PRIV.INS_PRIV_FLAG is
'InsertȨ��';

comment on column US_USER_COL_PRIV.DEL_PRIV_FLAG is
'DeleteȨ��';

comment on column US_USER_COL_PRIV.UPD_PRIV_FLAG is
'UpdateȨ��';

comment on column US_USER_COL_PRIV.SEL_PRIV_FLAG is
'SelectȨ��';

comment on column US_USER_COL_PRIV.AF_FLAG is
'������ֹ��־λ';

comment on column US_USER_COL_PRIV.TEMPSTART_BK_DATETIME is
'��ʱȨ�޿�ʼʱ��';

comment on column US_USER_COL_PRIV.TEMPEND_BK_DATETIME is
'��ʱȨ�޽���ʱ��';

comment on column US_USER_COL_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER_CONTACT
--==============================================================
create table US_USER_CONTACT
(
   USER_ID              CHAR(20)               not null,
   CONTACT_USER_ID      CHAR(20)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, CONTACT_USER_ID)
);

comment on table US_USER_CONTACT is
'�û�������ϵ�˹�����';

comment on column US_USER_CONTACT.USER_ID is
'�û�ID';

comment on column US_USER_CONTACT.CONTACT_USER_ID is
'�û�������ϵ��';

comment on column US_USER_CONTACT.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER_OPT_PRIV
--==============================================================
create table US_USER_OPT_PRIV
(
   OPT_CODE             CHAR(12)               not null,
   USER_ID              CHAR(20)               not null,
   PRIV_FLAG            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (OPT_CODE, USER_ID)
);

comment on table US_USER_OPT_PRIV is
'�û�����Ȩ�����ñ�';

comment on column US_USER_OPT_PRIV.OPT_CODE is
'��������';

comment on column US_USER_OPT_PRIV.USER_ID is
'�û���';

comment on column US_USER_OPT_PRIV.PRIV_FLAG is
'Ȩ��';

--==============================================================
-- Table: US_USER_ROLE
--==============================================================
create table US_USER_ROLE
(
   USER_ID              CHAR(20)               not null,
   DPRL_CODE            CHAR(8)                not null,
   USER_BK_WEIGHT       INTEGER                not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, DPRL_CODE)
);

comment on table US_USER_ROLE is
'�û���ɫ������';

comment on column US_USER_ROLE.USER_ID is
'�û���';

comment on column US_USER_ROLE.DPRL_CODE is
'���Ž�ɫ����';

comment on column US_USER_ROLE.USER_BK_WEIGHT is
'�û�Ȩ��';

comment on column US_USER_ROLE.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER_RS_PRIV
--==============================================================
create table US_USER_RS_PRIV
(
   USER_ID              CHAR(20)               not null,
   RS_CODE              CHAR(10)               not null,
   PRIV_TYPE            INTEGER                not null default 0,
   AF_FLAG              INTEGER                not null default 0,
   TEMPSTART_BK_DATETIME TIMESTAMP,
   TEMPEND_BK_DATETIME  TIMESTAMP,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, RS_CODE, PRIV_TYPE)
);

comment on table US_USER_RS_PRIV is
'�û���ԴȨ�ޱ�';

comment on column US_USER_RS_PRIV.USER_ID is
'�û���';

comment on column US_USER_RS_PRIV.RS_CODE is
'��Դ����';

comment on column US_USER_RS_PRIV.PRIV_TYPE is
'Ȩ������';

comment on column US_USER_RS_PRIV.AF_FLAG is
'������ֹ��־';

comment on column US_USER_RS_PRIV.TEMPSTART_BK_DATETIME is
'��ʱȨ�޿�ʼʱ��';

comment on column US_USER_RS_PRIV.TEMPEND_BK_DATETIME is
'��ʱȨ�޽���ʱ��';

comment on column US_USER_RS_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER_SOC_PRIV
--==============================================================
create table US_USER_SOC_PRIV
(
   USER_ID              CHAR(20)               not null,
   SOC_NAME             CHAR(20)               not null,
   PRIV_TYPE            INTEGER                not null default 0,
   AF_FLAG              INTEGER                not null default 0,
   TEMPSTART_BK_DATETIME TIMESTAMP,
   TEMPEND_BK_DATETIME  TIMESTAMP,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, SOC_NAME, PRIV_TYPE)
);

comment on table US_USER_SOC_PRIV is
'�û�����ԴȨ�ޱ�';

comment on column US_USER_SOC_PRIV.USER_ID is
'�û���';

comment on column US_USER_SOC_PRIV.SOC_NAME is
'����Դ����';

comment on column US_USER_SOC_PRIV.PRIV_TYPE is
'��Դ����';

comment on column US_USER_SOC_PRIV.AF_FLAG is
'������ֹ��־';

comment on column US_USER_SOC_PRIV.TEMPSTART_BK_DATETIME is
'��ʱȨ�޿�ʼʱ��';

comment on column US_USER_SOC_PRIV.TEMPEND_BK_DATETIME is
'��ʱȨ�޽���ʱ��';

comment on column US_USER_SOC_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER_SQL_PRIV
--==============================================================
create table US_USER_SQL_PRIV
(
   USER_ID              CHAR(20)               not null,
   SOC_NAME             CHAR(20)               not null,
   TBL_NAME             CHAR(50)               not null,
   PRIV_TYPE            INTEGER                not null default 0,
   INS_PRIV_FLAG        INTEGER                not null default 0,
   DEL_PRIV_FLAG        INTEGER                not null default 0,
   UPD_PRIV_FLAG        INTEGER                not null default 0,
   SEL_PRIV_FLAG        INTEGER                not null default 0,
   AF_FLAG              INTEGER                not null default 0,
   TEMPSTART_BK_DATETIME TIMESTAMP,
   TEMPEND_BK_DATETIME  TIMESTAMP,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, SOC_NAME, TBL_NAME, PRIV_TYPE)
);

comment on table US_USER_SQL_PRIV is
'�û�SQL����Ȩ�ޱ�';

comment on column US_USER_SQL_PRIV.USER_ID is
'�û���';

comment on column US_USER_SQL_PRIV.SOC_NAME is
'����Դ����';

comment on column US_USER_SQL_PRIV.TBL_NAME is
'����';

comment on column US_USER_SQL_PRIV.PRIV_TYPE is
'��Դ����';

comment on column US_USER_SQL_PRIV.INS_PRIV_FLAG is
'InsertȨ��';

comment on column US_USER_SQL_PRIV.DEL_PRIV_FLAG is
'DELETEȨ��';

comment on column US_USER_SQL_PRIV.UPD_PRIV_FLAG is
'UpdateȨ��';

comment on column US_USER_SQL_PRIV.SEL_PRIV_FLAG is
'SelectȨ��';

comment on column US_USER_SQL_PRIV.AF_FLAG is
'������ֹ��־';

comment on column US_USER_SQL_PRIV.TEMPSTART_BK_DATETIME is
'��ʱȨ�޿�ʼʱ��';

comment on column US_USER_SQL_PRIV.TEMPEND_BK_DATETIME is
'��ʱȨ�޽���ʱ��';

comment on column US_USER_SQL_PRIV.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: US_USER_TERM
--==============================================================
create table US_USER_TERM
(
   USER_ID              CHAR(20)               not null,
   TERM_NO              CHAR(40)               not null,
   CHANNEL_CODE         CHAR(2),
   DEPT_ID              CHAR(6),
   USER_CN_NAME         VARCHAR(50),
   DEPT_CN_NAME         VARCHAR(50),
   USE_STATE            INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (USER_ID, TERM_NO)
);

comment on table US_USER_TERM is
'�û������ն����ñ�';

comment on column US_USER_TERM.USER_ID is
'�û���';

comment on column US_USER_TERM.TERM_NO is
'�ն˺�';

comment on column US_USER_TERM.CHANNEL_CODE is
'��������';

comment on column US_USER_TERM.DEPT_ID is
'���ű���';

comment on column US_USER_TERM.USER_CN_NAME is
'�û�����';

comment on column US_USER_TERM.DEPT_CN_NAME is
'��������';

comment on column US_USER_TERM.USE_STATE is
'����״̬';

comment on column US_USER_TERM.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: WK_DEAL_DETAIL
--==============================================================
create table WK_DEAL_DETAIL
(
   PEND_WORK_SEQ        CHAR(17)               not null,
   DEAL_SEQ             INTEGER                not null default 0,
   DEAL_TYPE            INTEGER                not null default 0,
   DEAL_RES             INTEGER                not null default 0,
   DEAL_USER_ID         CHAR(20),
   DEAL_BK_DATE         DATE,
   DEAL_BK_TIME         TIME,
   DEAL_BK_DESC         VARCHAR(100),
   constraint "P_Key_1" primary key (PEND_WORK_SEQ, DEAL_SEQ)
);

comment on table WK_DEAL_DETAIL is
'��������ϸ';

comment on column WK_DEAL_DETAIL.PEND_WORK_SEQ is
'������������ˮ��';

comment on column WK_DEAL_DETAIL.DEAL_SEQ is
'�������';

comment on column WK_DEAL_DETAIL.DEAL_TYPE is
'������ʽ';

comment on column WK_DEAL_DETAIL.DEAL_RES is
'�������';

comment on column WK_DEAL_DETAIL.DEAL_USER_ID is
'������Ա';

comment on column WK_DEAL_DETAIL.DEAL_BK_DATE is
'��������';

comment on column WK_DEAL_DETAIL.DEAL_BK_TIME is
'����ʱ��';

comment on column WK_DEAL_DETAIL.DEAL_BK_DESC is
'����˵��';

--==============================================================
-- Table: WK_DEAL_STATE
--==============================================================
create table WK_DEAL_STATE
(
   PEND_WORK_SEQ        CHAR(17)               not null,
   SUBMIT_WORK_SEQ      CHAR(17),
   PEND_WORK_CODE       CHAR(10),
   PEND_SRV_NAME        CHAR(50),
   PEND_RS_CODE         CHAR(10),
   PEND_ARY_SOCNAME     VARCHAR(100),
   PENDWK_BK_EXPL       VARCHAR(500),
   PEND_DEAL_SEQ        INTEGER                not null default 0,
   PEND_USER_ID         CHAR(20),
   PEND_USER_CN_NAME    VARCHAR(50),
   PBL_CODE             VARCHAR(20),
   PROXY_USER_ID        CHAR(20),
   CRT_USER_ID          CHAR(20)               not null,
   CRT_USER_CN_NAME     VARCHAR(50),
   CRT_DEPT_ID          CHAR(6)                not null,
   CRT_DEPT_CN_NAME     VARCHAR(50),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   WORKFLOW_STATE       INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   RCD_STATE            INTEGER                not null default 0,
   APPLY_BK_EXPL        VARCHAR(500),
   constraint "P_Key_1" primary key (PEND_WORK_SEQ)
);

comment on table WK_DEAL_STATE is
'������״̬��';

comment on column WK_DEAL_STATE.PEND_WORK_SEQ is
'������������ˮ��';

comment on column WK_DEAL_STATE.SUBMIT_WORK_SEQ is
'�ύ������ˮ��';

comment on column WK_DEAL_STATE.PEND_WORK_CODE is
'�������������';

comment on column WK_DEAL_STATE.PEND_SRV_NAME is
'��������������';

comment on column WK_DEAL_STATE.PEND_RS_CODE is
'��������Դ����';

comment on column WK_DEAL_STATE.PEND_ARY_SOCNAME is
'����������Դ����';

comment on column WK_DEAL_STATE.PENDWK_BK_EXPL is
'����������˵��';

comment on column WK_DEAL_STATE.PEND_DEAL_SEQ is
'���������';

comment on column WK_DEAL_STATE.PEND_USER_ID is
'�������û�';

comment on column WK_DEAL_STATE.PEND_USER_CN_NAME is
'�������û�������';

comment on column WK_DEAL_STATE.PBL_CODE is
'���ⵥ����';

comment on column WK_DEAL_STATE.PROXY_USER_ID is
'�����û�';

comment on column WK_DEAL_STATE.CRT_USER_ID is
'�����û�';

comment on column WK_DEAL_STATE.CRT_USER_CN_NAME is
'�û�������';

comment on column WK_DEAL_STATE.CRT_DEPT_ID is
'��������';

comment on column WK_DEAL_STATE.CRT_DEPT_CN_NAME is
'����������';

comment on column WK_DEAL_STATE.CRT_BK_DATE is
'��������';

comment on column WK_DEAL_STATE.CRT_BK_TIME is
'����ʱ��';

comment on column WK_DEAL_STATE.WORKFLOW_STATE is
'����״̬';

comment on column WK_DEAL_STATE.BACKUP_FLD is
'����';

comment on column WK_DEAL_STATE.RCD_STATE is
'��¼״̬';

comment on column WK_DEAL_STATE.APPLY_BK_EXPL is
'��������˵��';

--==============================================================
-- Index: WK_DEAL_STATE_I1
--==============================================================
create index WK_DEAL_STATE_I1 on WK_DEAL_STATE (
   CRT_USER_ID          ASC,
   PROXY_USER_ID        ASC,
   PEND_SRV_NAME        ASC,
   PEND_DEAL_SEQ        ASC
);

--==============================================================
-- Index: WK_DEAL_STATE_I2
--==============================================================
create index WK_DEAL_STATE_I2 on WK_DEAL_STATE (
   PEND_SRV_NAME        ASC
);

--==============================================================
-- Index: WK_DEAL_STATE_I3
--==============================================================
create index WK_DEAL_STATE_I3 on WK_DEAL_STATE (
   PEND_USER_ID         ASC,
   WORKFLOW_STATE       ASC
);

--==============================================================
-- Table: WK_DETAIL_REGISTER
--==============================================================
create table WK_DETAIL_REGISTER
(
   PEND_WORK_SEQ        CHAR(17)               not null,
   INTE_DETAIL          BLOB,
   APROV_TYPE           INTEGER,
   CUSTOM_RS_CODE       CHAR(10),
   APPLY_HTML           BLOB,
   constraint "P_Key_1" primary key (PEND_WORK_SEQ)
);

comment on table WK_DETAIL_REGISTER is
'������������ϸ�ǼǱ�';

comment on column WK_DETAIL_REGISTER.PEND_WORK_SEQ is
'������������ˮ��';

comment on column WK_DETAIL_REGISTER.INTE_DETAIL is
'�ӿ���ϸ��Ϣ';

comment on column WK_DETAIL_REGISTER.APROV_TYPE is
'����չʾ����';

comment on column WK_DETAIL_REGISTER.CUSTOM_RS_CODE is
'����ҳ����Դ����';

comment on column WK_DETAIL_REGISTER.APPLY_HTML is
'����ҳ�����';

--==============================================================
-- Table: WK_WORK_PROCESS
--==============================================================
create table WK_WORK_PROCESS
(
   PEND_WORK_SEQ        CHAR(17)               not null,
   DEAL_SEQ             INTEGER                not null,
   PEND_USER_ID         CHAR(20),
   PEND_USER_CN_NAME    VARCHAR(50),
   PEND_TYPE            INTEGER,
   constraint "P_Key_1" primary key (PEND_WORK_SEQ, DEAL_SEQ)
);

comment on table WK_WORK_PROCESS is
'�����������̱�';

comment on column WK_WORK_PROCESS.PEND_WORK_SEQ is
'������������ˮ��';

comment on column WK_WORK_PROCESS.DEAL_SEQ is
'�������';

comment on column WK_WORK_PROCESS.PEND_USER_ID is
'������';

comment on column WK_WORK_PROCESS.PEND_USER_CN_NAME is
'������������';

comment on column WK_WORK_PROCESS.PEND_TYPE is
'������ʽ';




drop view VI_SYS_ENV_SERVER;

drop table BUILD_CONFIGFILE;

drop table BUILD_SCRIPT;

drop table BUILD_SCRIPT_EXE;

drop table BUILD_STEP;

drop table CE_ENVIRONMENT;

drop table CE_ENVIRONMENT_SERVER;

drop table CE_PROJECT;

drop table CE_SERVER;

drop table CE_SERVER_DS;

drop table CE_SYSTEM;

drop table CE_SYSTEM_CFG;

drop table CE_SYSTEM_TEMPLATE;

drop table ENV_BUILD_TASK;

drop table ENV_CONFIGFILE_MOD;

drop table ENV_TAG_STORAGE;

drop table ENV_TASK;

drop table ENV_TASK_EXE;

drop table PG_INTE_STEP;

drop table PG_PROGRAM;

drop table PG_RELE;

drop table PG_RELE_STEP;

drop table TP_COMPONENT;

drop table TP_COMP_QUOTE;

drop table TP_TEMPLATE;

drop table UU_EXSOC;

drop table UU_FILELIST;

drop table UU_PARAM;

drop table UU_SOC;

drop table UU_VERSOC;

drop distinct type PARAM_TYPE;

drop distinct type SYS_TYPE;

drop distinct type TEMPLATE_TYPE;

--==============================================================
-- Domain: PARAM_TYPE
--==============================================================
create distinct type PARAM_TYPE as INTEGER with comparisons;

--==============================================================
-- Domain: SYS_TYPE
--==============================================================
create distinct type SYS_TYPE as INTEGER with comparisons;

--==============================================================
-- Domain: TEMPLATE_TYPE
--==============================================================
create distinct type TEMPLATE_TYPE as INTEGER with comparisons;

--==============================================================
-- Table: BUILD_CONFIGFILE
--==============================================================
create table BUILD_CONFIGFILE
(
   FILE_WORK_SEQ        CHAR(17)               not null,
   WORK_ID              CHAR(14)               not null,
   CFG_TYPE             INTEGER,
   SERVER_NAME          CHAR(20),
   SERVER_IP            CHAR(20)               not null,
   FOPT_TYPE            INTEGER,
   FILE_BK_PATH         VARCHAR(200),
   FILE_BK_FNAME        VARCHAR(50),
   FILE_BK_CSUM         CHAR(20),
   DIR_YN_FLAG          INTEGER                not null default 0,
   OPT_STATUS           INTEGER,
   MODIFY_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (FILE_WORK_SEQ)
);

comment on table BUILD_CONFIGFILE is
'�������������ļ������';

comment on column BUILD_CONFIGFILE.FILE_WORK_SEQ is
'�ļ������ˮ��';

comment on column BUILD_CONFIGFILE.WORK_ID is
'������';

comment on column BUILD_CONFIGFILE.CFG_TYPE is
'��������';

comment on column BUILD_CONFIGFILE.SERVER_NAME is
'��������';

comment on column BUILD_CONFIGFILE.SERVER_IP is
'������IP';

comment on column BUILD_CONFIGFILE.FOPT_TYPE is
'��������';

comment on column BUILD_CONFIGFILE.FILE_BK_PATH is
'�ļ�·��';

comment on column BUILD_CONFIGFILE.FILE_BK_FNAME is
'�ļ���';

comment on column BUILD_CONFIGFILE.FILE_BK_CSUM is
'�ļ�CSUM';

comment on column BUILD_CONFIGFILE.DIR_YN_FLAG is
'�Ƿ�Ŀ¼��־';

comment on column BUILD_CONFIGFILE.OPT_STATUS is
'����״̬';

comment on column BUILD_CONFIGFILE.MODIFY_USER_ID is
'�޸���';

comment on column BUILD_CONFIGFILE.MODIFY_BK_DATE is
'�޸�����';

comment on column BUILD_CONFIGFILE.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column BUILD_CONFIGFILE.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: BUILD_SCRIPT
--==============================================================
create table BUILD_SCRIPT
(
   WORK_ID              CHAR(14)               not null,
   SCRIPT_TYPE          INTEGER                not null,
   SCIRPT_BK_SEQ        BIGINT                 not null,
   SCRIPT_METHOD        INTEGER,
   COMP_ID              CHAR(20),
   COMP_CN_NAME         VARCHAR(50),
   SOC_UUID             CHAR(32),
   COMP_PARAM_UUID      CHAR(32),
   INSTANCE_ID          CHAR(50),
   SCRIPT_TEXT          VARCHAR(1000),
   EXE_STATUS           INTEGER,
   EXE_RESULT           INTEGER,
   EXELOG_BK_PATH       VARCHAR(200),
   EXE_USER_ID          CHAR(20),
   START_BK_TM          TIMESTAMP,
   END_BK_TM            TIMESTAMP,
   TIME_USED            INTEGER,
   MODULE_TYPE          INTEGER,
   constraint "P_Key_1" primary key (WORK_ID, SCRIPT_TYPE, SCIRPT_BK_SEQ)
);

comment on table BUILD_SCRIPT is
'�����ű���Ϣ��';

comment on column BUILD_SCRIPT.WORK_ID is
'������';

comment on column BUILD_SCRIPT.SCRIPT_TYPE is
'�ű�����';

comment on column BUILD_SCRIPT.SCIRPT_BK_SEQ is
'�ű����';

comment on column BUILD_SCRIPT.SCRIPT_METHOD is
'�ű���ʽ';

comment on column BUILD_SCRIPT.COMP_ID is
'���ID';

comment on column BUILD_SCRIPT.COMP_CN_NAME is
'���������';

comment on column BUILD_SCRIPT.SOC_UUID is
'����ԴUUID';

comment on column BUILD_SCRIPT.COMP_PARAM_UUID is
'���������UUID';

comment on column BUILD_SCRIPT.INSTANCE_ID is
'ʵ��ID';

comment on column BUILD_SCRIPT.SCRIPT_TEXT is
'�ű�����';

comment on column BUILD_SCRIPT.EXE_STATUS is
'ִ��״̬';

comment on column BUILD_SCRIPT.EXE_RESULT is
'ִ�н��';

comment on column BUILD_SCRIPT.EXELOG_BK_PATH is
'ִ����־';

comment on column BUILD_SCRIPT.EXE_USER_ID is
'ִ����';

comment on column BUILD_SCRIPT.START_BK_TM is
'ִ�п�ʼʱ��';

comment on column BUILD_SCRIPT.END_BK_TM is
'ִ�н���ʱ��';

comment on column BUILD_SCRIPT.TIME_USED is
'��ʱ';

comment on column BUILD_SCRIPT.MODULE_TYPE is
'���ִ������';

--==============================================================
-- Table: BUILD_SCRIPT_EXE
--==============================================================
create table BUILD_SCRIPT_EXE
(
   INSTANCE_ID          CHAR(50)               not null,
   EXE_BK_NO            INTEGER                not null,
   SERVER_NAME          CHAR(20),
   SOC_NAME             CHAR(20)               not null,
   EXE_STATUS           INTEGER,
   EXE_RESULT           INTEGER,
   EXEC_TEXT            VARCHAR(500),
   START_BK_TM          TIMESTAMP,
   END_BK_TM            TIMESTAMP,
   TIME_USED            INTEGER,
   constraint "P_Key_1" primary key (INSTANCE_ID, EXE_BK_NO)
);

comment on table BUILD_SCRIPT_EXE is
'�����ű�ִ�б�';

comment on column BUILD_SCRIPT_EXE.INSTANCE_ID is
'ִ��ʵ��ID';

comment on column BUILD_SCRIPT_EXE.EXE_BK_NO is
'ִ�б��';

comment on column BUILD_SCRIPT_EXE.SERVER_NAME is
'��������';

comment on column BUILD_SCRIPT_EXE.SOC_NAME is
'����Դ��';

comment on column BUILD_SCRIPT_EXE.EXE_STATUS is
'ִ��״̬';

comment on column BUILD_SCRIPT_EXE.EXE_RESULT is
'ִ�н��';

comment on column BUILD_SCRIPT_EXE.EXEC_TEXT is
'ִ����Ϣ';

comment on column BUILD_SCRIPT_EXE.START_BK_TM is
'ִ�п�ʼʱ��';

comment on column BUILD_SCRIPT_EXE.END_BK_TM is
'ִ�н���ʱ��';

comment on column BUILD_SCRIPT_EXE.TIME_USED is
'��ʱ';

--==============================================================
-- Table: BUILD_STEP
--==============================================================
create table BUILD_STEP
(
   WORK_ID              CHAR(14)               not null,
   TEMPLATE_NAME        CHAR(50)               not null,
   PHASE_ID             INTEGER                not null,
   PHASE_BK_DESC        VARCHAR(100),
   SOC_UUID             CHAR(32),
   GEN_YN_FLAG          INTEGER,
   MODULE_TYPE          INTEGER,
   constraint "P_Key_1" primary key (WORK_ID, TEMPLATE_NAME, PHASE_ID)
);

comment on table BUILD_STEP is
'�����׶α�';

comment on column BUILD_STEP.WORK_ID is
'������';

comment on column BUILD_STEP.TEMPLATE_NAME is
'ģ����';

comment on column BUILD_STEP.PHASE_ID is
'�׶α��';

comment on column BUILD_STEP.PHASE_BK_DESC is
'�׶�����';

comment on column BUILD_STEP.SOC_UUID is
'����ԴUUID';

comment on column BUILD_STEP.GEN_YN_FLAG is
'�Ƿ�����ʵ��';

comment on column BUILD_STEP.MODULE_TYPE is
'���ִ������';

--==============================================================
-- Table: CE_ENVIRONMENT
--==============================================================
create table CE_ENVIRONMENT
(
   ENV_NAME             CHAR(20)               not null,
   ENV_CN_NAME          VARCHAR(50),
   ENV_BK_DESC          VARCHAR(100),
   ENV_TYPE             INTEGER,
   SYS_NAME             CHAR(10),
   ELE_TYPE             CHAR(20),
   DT_RANGE             INTEGER,
   CREATE_BK_DATE       DATE,
   CREATE_BK_TIME       TIME,
   CREATE_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (ENV_NAME)
);

comment on table CE_ENVIRONMENT is
'������';

comment on column CE_ENVIRONMENT.ENV_NAME is
'��������';

comment on column CE_ENVIRONMENT.ENV_CN_NAME is
'�������';

comment on column CE_ENVIRONMENT.ENV_BK_DESC is
'��������';

comment on column CE_ENVIRONMENT.ENV_TYPE is
'��������';

comment on column CE_ENVIRONMENT.SYS_NAME is
'Ӧ��ϵͳ';

comment on column CE_ENVIRONMENT.ELE_TYPE is
'����Ҫ��';

comment on column CE_ENVIRONMENT.DT_RANGE is
'���ݷ�Χ';

comment on column CE_ENVIRONMENT.CREATE_BK_DATE is
'��������';

comment on column CE_ENVIRONMENT.CREATE_BK_TIME is
'����ʱ��';

comment on column CE_ENVIRONMENT.CREATE_USER_ID is
'�����û�';

comment on column CE_ENVIRONMENT.MODIFY_BK_DATE is
'�޸�����';

comment on column CE_ENVIRONMENT.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column CE_ENVIRONMENT.MODIFY_USER_ID is
'�޸��û�';

comment on column CE_ENVIRONMENT.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_ENVIRONMENT_SERVER
--==============================================================
create table CE_ENVIRONMENT_SERVER
(
   ENV_NAME             CHAR(20)               not null,
   SERVER_TYPE          INTEGER                not null default 0,
   SERVER_NAME          CHAR(20)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (ENV_NAME, SERVER_TYPE, SERVER_NAME)
);

comment on table CE_ENVIRONMENT_SERVER is
'������������';

comment on column CE_ENVIRONMENT_SERVER.ENV_NAME is
'��������';

comment on column CE_ENVIRONMENT_SERVER.SERVER_TYPE is
'����������';

comment on column CE_ENVIRONMENT_SERVER.SERVER_NAME is
'����������';

comment on column CE_ENVIRONMENT_SERVER.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_PROJECT
--==============================================================
create table CE_PROJECT
(
   PROJECT_NAME         VARCHAR(100)           not null,
   PROJECT_SHORT_NAME   VARCHAR(20),
   PROJECT_BK_DESC      VARCHAR(100),
   SYS_NAME             CHAR(10),
   CREATE_BK_DATE       DATE,
   CREATE_BK_TIME       TIME,
   CREATE_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (PROJECT_NAME)
);

comment on table CE_PROJECT is
'��Ŀ��';

comment on column CE_PROJECT.PROJECT_NAME is
'��Ŀ���';

comment on column CE_PROJECT.PROJECT_SHORT_NAME is
'��Ŀ���';

comment on column CE_PROJECT.PROJECT_BK_DESC is
'��Ŀ����';

comment on column CE_PROJECT.SYS_NAME is
'Ӧ��ϵͳ';

comment on column CE_PROJECT.CREATE_BK_DATE is
'��������';

comment on column CE_PROJECT.CREATE_BK_TIME is
'����ʱ��';

comment on column CE_PROJECT.CREATE_USER_ID is
'�����û�';

comment on column CE_PROJECT.MODIFY_BK_DATE is
'�޸�����';

comment on column CE_PROJECT.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column CE_PROJECT.MODIFY_USER_ID is
'�޸��û�';

comment on column CE_PROJECT.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_SERVER
--==============================================================
create table CE_SERVER
(
   SERVER_NAME          CHAR(20)               not null,
   SERVER_CN_NAME       VARCHAR(50),
   SERVER_DESC          VARCHAR(200),
   SERVER_IP            CHAR(20),
   SERVER_OS            INTEGER,
   OS_SBK_VER           CHAR(20),
   SERVER_DB            CHAR(200),
   SERVER_MID_WARE      CHAR(20),
   CREATE_BK_DATE       DATE,
   CREATE_BK_TIME       TIME,
   CREATE_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (SERVER_NAME)
);

comment on table CE_SERVER is
'��������';

comment on column CE_SERVER.SERVER_NAME is
'����������';

comment on column CE_SERVER.SERVER_CN_NAME is
'���������';

comment on column CE_SERVER.SERVER_DESC is
'����������';

comment on column CE_SERVER.SERVER_IP is
'��������ַ';

comment on column CE_SERVER.SERVER_OS is
'����ϵͳ';

comment on column CE_SERVER.OS_SBK_VER is
'����ϵͳ�汾';

comment on column CE_SERVER.SERVER_DB is
'���ݿ�����';

comment on column CE_SERVER.SERVER_MID_WARE is
'�м��';

comment on column CE_SERVER.CREATE_BK_DATE is
'��������';

comment on column CE_SERVER.CREATE_BK_TIME is
'����ʱ��';

comment on column CE_SERVER.CREATE_USER_ID is
'�����û�';

comment on column CE_SERVER.MODIFY_BK_DATE is
'�޸�����';

comment on column CE_SERVER.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column CE_SERVER.MODIFY_USER_ID is
'�޸��û�';

comment on column CE_SERVER.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_SERVER_DS
--==============================================================
create table CE_SERVER_DS
(
   SERVER_NAME          CHAR(20)               not null,
   SOC_NAME             CHAR(20)               not null,
   APPLY_TYPE           CHAR(20),
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (SERVER_NAME, SOC_NAME)
);

comment on table CE_SERVER_DS is
'����������Դ��';

comment on column CE_SERVER_DS.SERVER_NAME is
'����������';

comment on column CE_SERVER_DS.SOC_NAME is
'����Դ����';

comment on column CE_SERVER_DS.APPLY_TYPE is
'����Դ��;';

comment on column CE_SERVER_DS.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_SYSTEM
--==============================================================
create table CE_SYSTEM
(
   SYS_NAME             CHAR(10)               not null,
   SYS_CN_NAME          VARCHAR(50),
   SYS_TYPE             INTEGER,
   SYS_BK_DESC          VARCHAR(100),
   CREATE_BK_DATE       DATE,
   CREATE_BK_TIME       TIME,
   CREATE_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (SYS_NAME)
);

comment on table CE_SYSTEM is
'Ӧ��ϵͳ��';

comment on column CE_SYSTEM.SYS_NAME is
'Ӧ��ϵͳ����';

comment on column CE_SYSTEM.SYS_CN_NAME is
'Ӧ��ϵͳ���';

comment on column CE_SYSTEM.SYS_TYPE is
'Ӧ��ϵͳ����';

comment on column CE_SYSTEM.SYS_BK_DESC is
'Ӧ��ϵͳ����';

comment on column CE_SYSTEM.CREATE_BK_DATE is
'��������';

comment on column CE_SYSTEM.CREATE_BK_TIME is
'����ʱ��';

comment on column CE_SYSTEM.CREATE_USER_ID is
'�����û�';

comment on column CE_SYSTEM.MODIFY_BK_DATE is
'�޸�����';

comment on column CE_SYSTEM.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column CE_SYSTEM.MODIFY_USER_ID is
'�޸��û�';

comment on column CE_SYSTEM.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_SYSTEM_CFG
--==============================================================
create table CE_SYSTEM_CFG
(
   SYS_NAME             CHAR(10)               not null,
   CFG_BK_FNAME         VARCHAR(50)            not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (SYS_NAME, CFG_BK_FNAME)
);

comment on table CE_SYSTEM_CFG is
'Ӧ��ϵͳ�����ļ���';

comment on column CE_SYSTEM_CFG.SYS_NAME is
'Ӧ��ϵͳ����';

comment on column CE_SYSTEM_CFG.CFG_BK_FNAME is
'�ļ���';

comment on column CE_SYSTEM_CFG.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: CE_SYSTEM_TEMPLATE
--==============================================================
create table CE_SYSTEM_TEMPLATE
(
   SYS_NAME             CHAR(10)               not null,
   TEMPLATE_TYPE        INTEGER                not null,
   TEMPLATE_NAME        CHAR(50)               not null,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (SYS_NAME, TEMPLATE_TYPE, TEMPLATE_NAME)
);

comment on table CE_SYSTEM_TEMPLATE is
'Ӧ��ϵͳģ���';

comment on column CE_SYSTEM_TEMPLATE.SYS_NAME is
'Ӧ��ϵͳ����';

comment on column CE_SYSTEM_TEMPLATE.TEMPLATE_TYPE is
'ģ������';

comment on column CE_SYSTEM_TEMPLATE.TEMPLATE_NAME is
'ģ������';

comment on column CE_SYSTEM_TEMPLATE.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: ENV_BUILD_TASK
--==============================================================
create table ENV_BUILD_TASK
(
   WORK_ID              CHAR(14)               not null,
   TEMPLATE_NAME        CHAR(50),
   TEMPLATE_PARAM_UUID  CHAR(32),
   EXELOG_BK_PATH       VARCHAR(200),
   BUILD_STEP_ID        INTEGER,
   TASK_STATUS          INTEGER,
   EXE_RESULT           INTEGER,
   EXE_USER_ID          CHAR(20),
   START_BK_TM          TIMESTAMP,
   END_BK_TM            TIMESTAMP,
   constraint "P_Key_1" primary key (WORK_ID)
);

comment on table ENV_BUILD_TASK is
'����������չ��';

comment on column ENV_BUILD_TASK.WORK_ID is
'������';

comment on column ENV_BUILD_TASK.TEMPLATE_NAME is
'ģ����';

comment on column ENV_BUILD_TASK.TEMPLATE_PARAM_UUID is
'ģ�����UUID';

comment on column ENV_BUILD_TASK.EXELOG_BK_PATH is
'������־';

comment on column ENV_BUILD_TASK.BUILD_STEP_ID is
'����������';

comment on column ENV_BUILD_TASK.TASK_STATUS is
'����״̬';

comment on column ENV_BUILD_TASK.EXE_RESULT is
'ִ�н��';

comment on column ENV_BUILD_TASK.EXE_USER_ID is
'ִ����';

comment on column ENV_BUILD_TASK.START_BK_TM is
'ִ�п�ʼʱ��';

comment on column ENV_BUILD_TASK.END_BK_TM is
'ִ�н���ʱ��';

--==============================================================
-- Table: ENV_CONFIGFILE_MOD
--==============================================================
create table ENV_CONFIGFILE_MOD
(
   FILE_WORK_SEQ        CHAR(17)               not null,
   BATCH_NO             CHAR(12),
   ENV_NAME             CHAR(20),
   SERVER_NAME          CHAR(20),
   SERVER_IP            CHAR(20)               not null,
   FOPT_TYPE            INTEGER,
   FILE_BK_PATH         VARCHAR(200),
   FILE_BK_FNAME        VARCHAR(50),
   FILE_BK_CSUM         CHAR(20),
   DIR_YN_FLAG          INTEGER                not null default 0,
   OPT_STATUS           INTEGER,
   MODIFY_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (FILE_WORK_SEQ)
);

comment on table ENV_CONFIGFILE_MOD is
'���������ļ������';

comment on column ENV_CONFIGFILE_MOD.FILE_WORK_SEQ is
'�ļ������ˮ��';

comment on column ENV_CONFIGFILE_MOD.BATCH_NO is
'���κ�';

comment on column ENV_CONFIGFILE_MOD.ENV_NAME is
'��������';

comment on column ENV_CONFIGFILE_MOD.SERVER_NAME is
'��������';

comment on column ENV_CONFIGFILE_MOD.SERVER_IP is
'������IP';

comment on column ENV_CONFIGFILE_MOD.FOPT_TYPE is
'��������';

comment on column ENV_CONFIGFILE_MOD.FILE_BK_PATH is
'�ļ�·��';

comment on column ENV_CONFIGFILE_MOD.FILE_BK_FNAME is
'�ļ���';

comment on column ENV_CONFIGFILE_MOD.FILE_BK_CSUM is
'�ļ�CSUM';

comment on column ENV_CONFIGFILE_MOD.DIR_YN_FLAG is
'�Ƿ�Ŀ¼��־';

comment on column ENV_CONFIGFILE_MOD.OPT_STATUS is
'����״̬';

comment on column ENV_CONFIGFILE_MOD.MODIFY_USER_ID is
'�޸���';

comment on column ENV_CONFIGFILE_MOD.MODIFY_BK_DATE is
'�޸�����';

comment on column ENV_CONFIGFILE_MOD.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column ENV_CONFIGFILE_MOD.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: ENV_TAG_STORAGE
--==============================================================
create table ENV_TAG_STORAGE
(
   STORAGE_ID           CHAR(14)               not null,
   STORAGE_BK_DESC      VARCHAR(100),
   ENV_NAME             CHAR(20),
   PROJECT_NAME         VARCHAR(100),
   INSTANCE_ID          CHAR(50),
   EXE_SOC_UUID         CHAR(32),
   INTE_VER_NUM         CHAR(10),
   STORAGE_LIST_UUID    CHAR(32),
   TAR_VERSOC_UUID      CHAR(32),
   TAR_VER_NUM          CHAR(10),
   STORAGE_STATUS       INTEGER,
   CRT_USER_ID          CHAR(20),
   STORAGE_RESULT       INTEGER,
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   STORAGE_USER_ID      CHAR(20),
   START_BK_TM          TIMESTAMP,
   END_BK_TM            TIMESTAMP,
   LOG_BK_PATH          VARCHAR(200),
   TIME_USED            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (STORAGE_ID)
);

comment on table ENV_TAG_STORAGE is
'Ŀ������';

comment on column ENV_TAG_STORAGE.STORAGE_ID is
'�����';

comment on column ENV_TAG_STORAGE.STORAGE_BK_DESC is
'�������';

comment on column ENV_TAG_STORAGE.ENV_NAME is
'��������';

comment on column ENV_TAG_STORAGE.PROJECT_NAME is
'��Ŀ���';

comment on column ENV_TAG_STORAGE.INSTANCE_ID is
'ʵ��ID';

comment on column ENV_TAG_STORAGE.EXE_SOC_UUID is
'ִ������ԴUUID';

comment on column ENV_TAG_STORAGE.INTE_VER_NUM is
'���ɰ汾��';

comment on column ENV_TAG_STORAGE.STORAGE_LIST_UUID is
'����嵥UUID';

comment on column ENV_TAG_STORAGE.TAR_VERSOC_UUID is
'Ŀ��汾����ԴUUID';

comment on column ENV_TAG_STORAGE.TAR_VER_NUM is
'Ŀ��汾��';

comment on column ENV_TAG_STORAGE.STORAGE_STATUS is
'���״̬';

comment on column ENV_TAG_STORAGE.CRT_USER_ID is
'������';

comment on column ENV_TAG_STORAGE.STORAGE_RESULT is
'�����';

comment on column ENV_TAG_STORAGE.CRT_BK_DATE is
'��������';

comment on column ENV_TAG_STORAGE.CRT_BK_TIME is
'����ʱ��';

comment on column ENV_TAG_STORAGE.STORAGE_USER_ID is
'�����';

comment on column ENV_TAG_STORAGE.START_BK_TM is
'��⿪ʼʱ��';

comment on column ENV_TAG_STORAGE.END_BK_TM is
'������ʱ��';

comment on column ENV_TAG_STORAGE.LOG_BK_PATH is
'�����־ȫ·��';

comment on column ENV_TAG_STORAGE.TIME_USED is
'��ʱ';

--==============================================================
-- Table: ENV_TASK
--==============================================================
create table ENV_TASK
(
   WORK_ID              CHAR(14)               not null,
   TASK_TYPE            INTEGER,
   TASK_BK_DESC         VARCHAR(100),
   ROL_WORK_ID          CHAR(14),
   ENV_NAME             CHAR(20),
   PROJECT_NAME         VARCHAR(100),
   PROG_ID              CHAR(14),
   INSTANCE_ID          CHAR(50),
   EXE_METHOD           INTEGER,
   CODE_LIST_UUID       CHAR(32),
   CODE_VER_NUM         CHAR(10),
   TAG_LIST_UUID        CHAR(32),
   TAGPAC_LIST_UUID     CHAR(32),
   TARGET_VER_NUM       CHAR(10),
   PUB_LIST_UUID        CHAR(32),
   TASK_STATUS          INTEGER,
   EXE_RESULT           INTEGER,
   EXELOG_BK_PATH       VARCHAR(200),
   CRT_USER_ID          CHAR(20),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   EXE_USER_ID          CHAR(20),
   START_BK_TM          TIMESTAMP,
   END_BK_TM            TIMESTAMP,
   TIME_USED            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (WORK_ID)
);

comment on table ENV_TASK is
'���������';

comment on column ENV_TASK.WORK_ID is
'������';

comment on column ENV_TASK.TASK_TYPE is
'��������';

comment on column ENV_TASK.TASK_BK_DESC is
'��������';

comment on column ENV_TASK.ROL_WORK_ID is
'����������';

comment on column ENV_TASK.ENV_NAME is
'��������';

comment on column ENV_TASK.PROJECT_NAME is
'������Ŀ';

comment on column ENV_TASK.PROG_ID is
'�������';

comment on column ENV_TASK.INSTANCE_ID is
'ʵ��ID';

comment on column ENV_TASK.EXE_METHOD is
'ִ�ж���';

comment on column ENV_TASK.CODE_LIST_UUID is
'����Դ���嵥UUID';

comment on column ENV_TASK.CODE_VER_NUM is
'����Դ��汾��';

comment on column ENV_TASK.TAG_LIST_UUID is
'����Ŀ���嵥UUID';

comment on column ENV_TASK.TAGPAC_LIST_UUID is
'����Ŀ����嵥UUID';

comment on column ENV_TASK.TARGET_VER_NUM is
'����Ŀ��汾��';

comment on column ENV_TASK.PUB_LIST_UUID is
'�����嵥UUID';

comment on column ENV_TASK.TASK_STATUS is
'����״̬';

comment on column ENV_TASK.EXE_RESULT is
'ִ�н��';

comment on column ENV_TASK.EXELOG_BK_PATH is
'ִ����־';

comment on column ENV_TASK.CRT_USER_ID is
'������';

comment on column ENV_TASK.CRT_BK_DATE is
'��������';

comment on column ENV_TASK.CRT_BK_TIME is
'����ʱ��';

comment on column ENV_TASK.EXE_USER_ID is
'ִ����';

comment on column ENV_TASK.START_BK_TM is
'ִ�п�ʼʱ��';

comment on column ENV_TASK.END_BK_TM is
'ִ�н���ʱ��';

comment on column ENV_TASK.TIME_USED is
'��ʱ';

--==============================================================
-- Table: ENV_TASK_EXE
--==============================================================
create table ENV_TASK_EXE
(
   WORK_ID              CHAR(14)               not null,
   EXE_BK_NO            INTEGER                not null,
   STEP_BK_NO           INTEGER,
   EXE_SOC_NAME         CHAR(20),
   STEP_BK_DESC         VARCHAR(100),
   EXE_TYPE             INTEGER,
   EXE_STATUS           INTEGER,
   EXE_BK_MSG           VARCHAR(500),
   TASK_EXE_RESULT      INTEGER,
   START_BK_TM          TIMESTAMP,
   END_BK_TM            TIMESTAMP,
   TIME_USED            INTEGER                not null default 0,
   constraint "P_Key_1" primary key (WORK_ID, EXE_BK_NO)
);

comment on table ENV_TASK_EXE is
'����ִ����Ϣ��';

comment on column ENV_TASK_EXE.WORK_ID is
'������';

comment on column ENV_TASK_EXE.EXE_BK_NO is
'ִ�б��';

comment on column ENV_TASK_EXE.STEP_BK_NO is
'�׶β�����';

comment on column ENV_TASK_EXE.EXE_SOC_NAME is
'ִ������Դ';

comment on column ENV_TASK_EXE.STEP_BK_DESC is
'�׶β�������';

comment on column ENV_TASK_EXE.EXE_TYPE is
'ִ�з�ʽ';

comment on column ENV_TASK_EXE.EXE_STATUS is
'ִ��״̬';

comment on column ENV_TASK_EXE.EXE_BK_MSG is
'ִ����Ϣ';

comment on column ENV_TASK_EXE.TASK_EXE_RESULT is
'ִ�н��';

comment on column ENV_TASK_EXE.START_BK_TM is
'ִ�п�ʼʱ��';

comment on column ENV_TASK_EXE.END_BK_TM is
'ִ�н���ʱ��';

comment on column ENV_TASK_EXE.TIME_USED is
'��ʱ';

--==============================================================
-- Table: PG_INTE_STEP
--==============================================================
create table PG_INTE_STEP
(
   PROG_ID              CHAR(14)               not null,
   STEP_ID              INTEGER                not null default 0,
   STEP_EXPL            CHAR(20),
   STEP_TYPE            INTEGER,
   SOC_UUID             CHAR(32),
   CODE_VERSOC_UUID     CHAR(32),
   STEP_BK_SCRIPT       VARCHAR(1000),
   COMPILE_TYPE         INTEGER,
   COMPLIE_BK_PATH      VARCHAR(200),
   ENV_VARIABLE         VARCHAR(500),
   COMPILE_PARAM        VARCHAR(200),
   TAR_VERSOC_UUID      CHAR(32),
   STORAGE_LIST_UUID    CHAR(32),
   constraint "P_Key_1" primary key (PROG_ID, STEP_ID)
);

comment on table PG_INTE_STEP is
'���ɷ��������';

comment on column PG_INTE_STEP.PROG_ID is
'�������';

comment on column PG_INTE_STEP.STEP_ID is
'������';

comment on column PG_INTE_STEP.STEP_EXPL is
'����˵��';

comment on column PG_INTE_STEP.STEP_TYPE is
'��������';

comment on column PG_INTE_STEP.SOC_UUID is
'����ԴUUID';

comment on column PG_INTE_STEP.CODE_VERSOC_UUID is
'Դ��汾����ԴUUID';

comment on column PG_INTE_STEP.STEP_BK_SCRIPT is
'�ű�';

comment on column PG_INTE_STEP.COMPILE_TYPE is
'��������';

comment on column PG_INTE_STEP.COMPLIE_BK_PATH is
'����·��';

comment on column PG_INTE_STEP.ENV_VARIABLE is
'��������';

comment on column PG_INTE_STEP.COMPILE_PARAM is
'�������';

comment on column PG_INTE_STEP.TAR_VERSOC_UUID is
'Ŀ��汾����ԴUUID';

comment on column PG_INTE_STEP.STORAGE_LIST_UUID is
'����嵥UUID';

--==============================================================
-- Table: PG_PROGRAM
--==============================================================
create table PG_PROGRAM
(
   PROG_ID              CHAR(14)               not null,
   PROG_NAME            VARCHAR(50),
   ENV_NAME             CHAR(20),
   PROG_BK_DESC         VARCHAR(100),
   PROG_TYPE            INTEGER,
   IS_PUBLISH           INTEGER                not null default 0,
   PROG_BK_PATH         VARCHAR(200),
   CRT_USER_ID          CHAR(20),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   constraint "P_Key_1" primary key (PROG_ID)
);

comment on table PG_PROGRAM is
'����������';

comment on column PG_PROGRAM.PROG_ID is
'�������';

comment on column PG_PROGRAM.PROG_NAME is
'��������';

comment on column PG_PROGRAM.ENV_NAME is
'��������';

comment on column PG_PROGRAM.PROG_BK_DESC is
'��������';

comment on column PG_PROGRAM.PROG_TYPE is
'��������';

comment on column PG_PROGRAM.IS_PUBLISH is
'�Ƿ񷢲�';

comment on column PG_PROGRAM.PROG_BK_PATH is
'����·��';

comment on column PG_PROGRAM.CRT_USER_ID is
'������';

comment on column PG_PROGRAM.CRT_BK_DATE is
'��������';

comment on column PG_PROGRAM.CRT_BK_TIME is
'����ʱ��';

--==============================================================
-- Table: PG_RELE
--==============================================================
create table PG_RELE
(
   PROG_ID              CHAR(14)               not null,
   VERSOC_UUID          CHAR(32),
   PUB_TEMPLATE_NAME    CHAR(50),
   PUBL_PARAM_UUID      CHAR(32),
   ROL_TEMPLATE_NAME    CHAR(50),
   ROLL_PARAM_UUID      CHAR(32),
   constraint "P_Key_1" primary key (PROG_ID)
);

comment on table PG_RELE is
'����������չ��';

comment on column PG_RELE.PROG_ID is
'�������';

comment on column PG_RELE.VERSOC_UUID is
'�汾����ԴUUID';

comment on column PG_RELE.PUB_TEMPLATE_NAME is
'����ģ��';

comment on column PG_RELE.PUBL_PARAM_UUID is
'����ģ�����UUID';

comment on column PG_RELE.ROL_TEMPLATE_NAME is
'����ģ��';

comment on column PG_RELE.ROLL_PARAM_UUID is
'����ģ�����UUID';

--==============================================================
-- Table: PG_RELE_STEP
--==============================================================
create table PG_RELE_STEP
(
   PROG_ID              CHAR(14)               not null,
   TEMPLATE_NAME        CHAR(50)               not null,
   PHASE_ID             INTEGER                not null,
   PHASE_BK_DESC        VARCHAR(100),
   SOC_UUID             CHAR(32)               not null,
   GEN_YN_FLAG          INTEGER                not null default 0,
   MODULE_TYPE          INTEGER,
   constraint "P_Key_1" primary key (PROG_ID, TEMPLATE_NAME, PHASE_ID)
);

comment on table PG_RELE_STEP is
'���������׶α�';

comment on column PG_RELE_STEP.PROG_ID is
'�������';

comment on column PG_RELE_STEP.TEMPLATE_NAME is
'ģ����';

comment on column PG_RELE_STEP.PHASE_ID is
'�׶α��';

comment on column PG_RELE_STEP.PHASE_BK_DESC is
'�׶�����';

comment on column PG_RELE_STEP.SOC_UUID is
'����ԴUUID';

comment on column PG_RELE_STEP.GEN_YN_FLAG is
'�Ƿ�����ʵ��';

comment on column PG_RELE_STEP.MODULE_TYPE is
'���ִ������';

--==============================================================
-- Table: TP_COMPONENT
--==============================================================
create table TP_COMPONENT
(
   COMP_ID              CHAR(20)               not null,
   COMP_CN_NAME         VARCHAR(50),
   COMP_BK_DESC         VARCHAR(100),
   COMP_TYPE            INTEGER,
   MODULE_TYPE          INTEGER,
   SHARE_RANGE          CHAR(10),
   PUBLISH_STATE        INTEGER,
   OPERATING_SYSTEM     CHAR(20),
   CRT_USER_ID          CHAR(20),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   MODIFY_USER_ID       CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (COMP_ID)
);

comment on table TP_COMPONENT is
'�����Ϣ��';

comment on column TP_COMPONENT.COMP_ID is
'���ID';

comment on column TP_COMPONENT.COMP_CN_NAME is
'���������';

comment on column TP_COMPONENT.COMP_BK_DESC is
'�������';

comment on column TP_COMPONENT.COMP_TYPE is
'�������';

comment on column TP_COMPONENT.MODULE_TYPE is
'���ִ������';

comment on column TP_COMPONENT.SHARE_RANGE is
'������Χ';

comment on column TP_COMPONENT.PUBLISH_STATE is
'����״̬';

comment on column TP_COMPONENT.OPERATING_SYSTEM is
'��Ӧ����';

comment on column TP_COMPONENT.CRT_USER_ID is
'������';

comment on column TP_COMPONENT.CRT_BK_DATE is
'��������';

comment on column TP_COMPONENT.CRT_BK_TIME is
'����ʱ��';

comment on column TP_COMPONENT.MODIFY_USER_ID is
'�޸���';

comment on column TP_COMPONENT.MODIFY_BK_DATE is
'�޸�����';

comment on column TP_COMPONENT.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column TP_COMPONENT.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: TP_COMP_QUOTE
--==============================================================
create table TP_COMP_QUOTE
(
   COMP_ID              CHAR(20)               not null,
   QUOTE_COMP_ID        CHAR(20)               not null,
   QUOTE_COMP_TYPE      INTEGER,
   constraint "P_Key_1" primary key (COMP_ID, QUOTE_COMP_ID)
);

comment on table TP_COMP_QUOTE is
'�����������ñ�';

comment on column TP_COMP_QUOTE.COMP_ID is
'���ID';

comment on column TP_COMP_QUOTE.QUOTE_COMP_ID is
'�������ID';

comment on column TP_COMP_QUOTE.QUOTE_COMP_TYPE is
'�����������';

--==============================================================
-- Table: TP_TEMPLATE
--==============================================================
create table TP_TEMPLATE
(
   TEMPLATE_NAME        CHAR(50)               not null,
   TEMPLATE_FORMATE     INTEGER,
   TEMPLATE_CN_NAME     VARCHAR(50),
   TP_CLASS_NAME        VARCHAR(100),
   SCRIPT_FILE_PATH     VARCHAR(200),
   REFERENCE_COMP_ID    CHAR(20),
   TEMPLATE_TYPE        INTEGER,
   OPERATING_SYSTEM     CHAR(20),
   PUBLISH_STATE        INTEGER,
   TEMPLATE_BK_DESC     VARCHAR(100),
   CRT_BK_DATE          DATE,
   CRT_BK_TIME          TIME,
   CRT_USER_ID          CHAR(20),
   MODIFY_BK_DATE       DATE,
   MODIFY_BK_TIME       TIME,
   MODIFY_USER_ID       CHAR(20),
   BACKUP_FLD           VARCHAR(50),
   constraint "P_Key_1" primary key (TEMPLATE_NAME)
);

comment on table TP_TEMPLATE is
'Ͷ��ģ���';

comment on column TP_TEMPLATE.TEMPLATE_NAME is
'ģ������';

comment on column TP_TEMPLATE.TEMPLATE_FORMATE is
'ģ���ʽ';

comment on column TP_TEMPLATE.TEMPLATE_CN_NAME is
'ģ��������';

comment on column TP_TEMPLATE.TP_CLASS_NAME is
'ģ������';

comment on column TP_TEMPLATE.SCRIPT_FILE_PATH is
'ģ��·��';

comment on column TP_TEMPLATE.REFERENCE_COMP_ID is
'����ID';

comment on column TP_TEMPLATE.TEMPLATE_TYPE is
'ģ������';

comment on column TP_TEMPLATE.OPERATING_SYSTEM is
'����ϵͳ';

comment on column TP_TEMPLATE.PUBLISH_STATE is
'����״̬';

comment on column TP_TEMPLATE.TEMPLATE_BK_DESC is
'ģ������';

comment on column TP_TEMPLATE.CRT_BK_DATE is
'��������';

comment on column TP_TEMPLATE.CRT_BK_TIME is
'����ʱ��';

comment on column TP_TEMPLATE.CRT_USER_ID is
'�����û�';

comment on column TP_TEMPLATE.MODIFY_BK_DATE is
'�޸�����';

comment on column TP_TEMPLATE.MODIFY_BK_TIME is
'�޸�ʱ��';

comment on column TP_TEMPLATE.MODIFY_USER_ID is
'�޸��û�';

comment on column TP_TEMPLATE.BACKUP_FLD is
'�����ֶ�';

--==============================================================
-- Table: UU_EXSOC
--==============================================================
create table UU_EXSOC
(
   SOC_UUID             CHAR(32)               not null,
   SOC_NAME             CHAR(20)               not null,
   SERVER_NAME          CHAR(20),
   constraint "P_Key_1" primary key (SOC_UUID, SOC_NAME)
);

comment on table UU_EXSOC is
'ִ������Դ������';

comment on column UU_EXSOC.SOC_UUID is
'����ԴUUID';

comment on column UU_EXSOC.SOC_NAME is
'����Դ��';

comment on column UU_EXSOC.SERVER_NAME is
'��������';

--==============================================================
-- Table: UU_FILELIST
--==============================================================
create table UU_FILELIST
(
   LIST_UUID            CHAR(32)               not null,
   FILE_WORK_SEQ        CHAR(17)               not null,
   FILE_PATH            VARCHAR(200),
   FILE_NAME            VARCHAR(50),
   FILE_TYPE            VARCHAR(10),
   FILE_SIZE            INTEGER,
   PACKAGE_NAME         VARCHAR(50),
   SERVER_NAME          CHAR(20),
   constraint "P_Key_1" primary key (LIST_UUID, FILE_WORK_SEQ)
);

comment on table UU_FILELIST is
'�ļ��嵥��';

comment on column UU_FILELIST.LIST_UUID is
'�嵥UUID';

comment on column UU_FILELIST.FILE_WORK_SEQ is
'�ļ���ˮ��';

comment on column UU_FILELIST.FILE_PATH is
'�ļ�Ŀ¼';

comment on column UU_FILELIST.FILE_NAME is
'�ļ���';

comment on column UU_FILELIST.FILE_TYPE is
'�ļ�����';

comment on column UU_FILELIST.FILE_SIZE is
'�ļ���С';

comment on column UU_FILELIST.PACKAGE_NAME is
'��������';

comment on column UU_FILELIST.SERVER_NAME is
'������������';

--==============================================================
-- Table: UU_PARAM
--==============================================================
create table UU_PARAM
(
   PARAM_UUID           CHAR(32)               not null,
   PARAM_NAME           CHAR(50)               not null,
   PARAM_TYPE           INTEGER,
   PARAM_VALUE          VARCHAR(200),
   PARAM_CN_NAME        VARCHAR(50),
   PARAM_BK_DESC        VARCHAR(100),
   PARAM_MODIFY_FLAG    INTEGER                not null default 0,
   BACKUP_FLD           VARCHAR(50),
   PARAM_GROUP          CHAR(20),
   PHASE_NO             INTEGER,
   constraint "P_Key_1" primary key (PARAM_UUID, PARAM_NAME)
);

comment on table UU_PARAM is
'ģ�����������';

comment on column UU_PARAM.PARAM_UUID is
'����UUID';

comment on column UU_PARAM.PARAM_NAME is
'������';

comment on column UU_PARAM.PARAM_TYPE is
'��������';

comment on column UU_PARAM.PARAM_VALUE is
'����ֵ';

comment on column UU_PARAM.PARAM_CN_NAME is
'����������';

comment on column UU_PARAM.PARAM_BK_DESC is
'��������';

comment on column UU_PARAM.PARAM_MODIFY_FLAG is
'�Ƿ���޸�';

comment on column UU_PARAM.BACKUP_FLD is
'�����ֶ�';

comment on column UU_PARAM.PARAM_GROUP is
'��������';

comment on column UU_PARAM.PHASE_NO is
'�׶κ�';

--==============================================================
-- Table: UU_SOC
--==============================================================
create table UU_SOC
(
   SOC_UUID             CHAR(32)               not null,
   SOC_WORK_SEQ         CHAR(17)               not null,
   EXE_SERVER_NAME      CHAR(20),
   EXE_SOC_NAME         CHAR(20)               not null,
   VER_SERVER_NAME      CHAR(20),
   VER_SOC_NAME         CHAR(20)               not null,
   CODE_BK_DIR          VARCHAR(100)           not null,
   constraint "P_Key_1" primary key (SOC_UUID, SOC_WORK_SEQ)
);

comment on table UU_SOC is
'����Դ������';

comment on column UU_SOC.SOC_UUID is
'����ԴUUID';

comment on column UU_SOC.SOC_WORK_SEQ is
'������ˮ��';

comment on column UU_SOC.EXE_SERVER_NAME is
'ִ�з�������';

comment on column UU_SOC.EXE_SOC_NAME is
'ִ������Դ��';

comment on column UU_SOC.VER_SERVER_NAME is
'�汾��������';

comment on column UU_SOC.VER_SOC_NAME is
'�汾����Դ��';

comment on column UU_SOC.CODE_BK_DIR is
'Դ��汾Ŀ¼';

--==============================================================
-- Table: UU_VERSOC
--==============================================================
create table UU_VERSOC
(
   VERSOC_UUID          CHAR(32)               not null,
   CODE_SOC_NAME        CHAR(20)               not null,
   CODE_BK_DIR          VARCHAR(100)           not null,
   CODE_SERVER_NAME     CHAR(20),
   constraint "P_Key_1" primary key (VERSOC_UUID, CODE_SOC_NAME, CODE_BK_DIR)
);

comment on table UU_VERSOC is
'�汾����Դ������';

comment on column UU_VERSOC.VERSOC_UUID is
'�汾����ԴUUID';

comment on column UU_VERSOC.CODE_SOC_NAME is
'Դ��汾����Դ';

comment on column UU_VERSOC.CODE_BK_DIR is
'Դ��汾Ŀ¼';

comment on column UU_VERSOC.CODE_SERVER_NAME is
'Դ��汾������';

--==============================================================
-- View: VI_SYS_ENV_SERVER
--==============================================================
create view VI_SYS_ENV_SERVER as
select sys.SYS_NAME,sys.SYS_CN_NAME,sys.SYS_BK_DESC,sys.SYS_TYPE,en.ENV_NAME,en.ENV_CN_NAME,en.ENV_BK_DESC,en.ENV_TYPE,en.DT_RANGE,se.SERVER_NAME,se.SERVER_CN_NAME,SERVER_DESC,se.SERVER_IP,se.SERVER_OS,se.OS_SBK_VER,se.SERVER_DB,se.SERVER_MID_WARE from ce_system sys left join ce_environment en on sys.SYS_NAME=en.SYS_NAME LEFT JOIN ce_environment_server es on en.ENV_NAME=es.ENV_NAME left JOIN ce_server se on es.SERVER_NAME=se.SERVER_NAME;

comment on table VI_SYS_ENV_SERVER is
'Ӧ�û�����������ͼ';
